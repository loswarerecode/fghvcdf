package com.oxidesp.cheat;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * Non-root memory reader using /proc/<pid>/mem.
 * Works in GBox — same UID shared with the game process.
 * All reads are little-endian (ARM64 Android).
 *
 * FIXES vs original:
 *  1. findModuleBase() now accepts r--p, r-xp AND r--p (new Android linker maps both)
 *  2. open() tries rw first, falls back to r (same as before but logged)
 *  3. Added isOpen() helper for health checks
 */
public class MemReader {

    private static final String TAG = "OxideESP_Mem";

    private final int targetPid;
    private RandomAccessFile memFile;
    private long il2cppBase;
    private long unityBase;

    public MemReader(int pid) {
        this.targetPid = pid;
    }

    // ------------------------------------------------------------------ //
    //  Init                                                                //
    // ------------------------------------------------------------------ //

    public boolean init() {
        return init(null);
    }

    public boolean init(DebugInfo dbg) {
        try {
            // Try rw first (GBox shared-UID), fall back to r
            try {
                memFile = new RandomAccessFile("/proc/" + targetPid + "/mem", "rw");
                Log.d(TAG, "mem opened rw");
            } catch (Exception e) {
                try {
                    memFile = new RandomAccessFile("/proc/" + targetPid + "/mem", "r");
                    Log.d(TAG, "mem opened r (rw denied)");
                } catch (Exception e2) {
                    if (dbg != null) dbg.stepMemOpen.fail("open failed: " + e2.getMessage());
                    Log.e(TAG, "Cannot open mem: " + e2.getMessage());
                    return false;
                }
            }
            if (dbg != null) dbg.stepMemOpen.ok("open OK");

            il2cppBase = findModuleBase("libil2cpp.so");
            unityBase  = findModuleBase("libunity.so");

            if (dbg != null) {
                if (il2cppBase != 0)
                    dbg.stepIl2Cpp.ok("0x" + Long.toHexString(il2cppBase).toUpperCase());
                else
                    dbg.stepIl2Cpp.fail("NOT FOUND in /proc/" + targetPid + "/maps");

                if (unityBase != 0)
                    dbg.stepUnity.ok("0x" + Long.toHexString(unityBase).toUpperCase());
                else
                    dbg.stepUnity.warn("NOT FOUND");
            }

            if (il2cppBase == 0) {
                Log.e(TAG, "libil2cpp.so not found in maps for pid=" + targetPid);
                return false;
            }
            if (unityBase == 0) {
                Log.w(TAG, "libunity.so not found — continuing without it");
            }

            Log.d(TAG, String.format("il2cpp=0x%X  unity=0x%X", il2cppBase, unityBase));
            return true;
        } catch (Exception e) {
            if (dbg != null) dbg.stepMemOpen.fail(e.getMessage() != null ? e.getMessage() : "exception");
            Log.e(TAG, "init failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Find the load base of a .so by scanning /proc/<pid>/maps.
     * Accepts r--p, r-xp, r-x-- — covers all Android linker variants including GBox.
     */
    public long findModuleBase(String libName) {
        try {
            RandomAccessFile maps = new RandomAccessFile(
                    "/proc/" + targetPid + "/maps", "r");
            String line;
            while ((line = maps.readLine()) != null) {
                if (!line.contains(libName)) continue;
                // Accept any readable mapping that starts the library
                if (line.contains("r-xp") || line.contains("r--p") || line.contains("r-x-")) {
                    String addrPart = line.split("-")[0].trim();
                    try {
                        long base = Long.parseLong(addrPart, 16);
                        if (base > 0) {
                            maps.close();
                            Log.d(TAG, libName + " base=0x" + Long.toHexString(base));
                            return base;
                        }
                    } catch (NumberFormatException ignored) {}
                }
            }
            maps.close();
        } catch (IOException e) {
            Log.e(TAG, "maps error: " + e.getMessage());
        }
        return 0L;
    }

    public boolean isOpen() { return memFile != null; }

    public long getIl2CppBase() { return il2cppBase; }
    public long getUnityBase()  { return unityBase;  }

    // ------------------------------------------------------------------ //
    //  Primitive reads                                                     //
    // ------------------------------------------------------------------ //

    public byte[] readBytes(long address, int count) {
        if (memFile == null || address <= 0) return new byte[count];
        try {
            byte[] buf = new byte[count];
            memFile.seek(address);
            int total = 0;
            while (total < count) {
                int n = memFile.read(buf, total, count - total);
                if (n <= 0) break;
                total += n;
            }
            return buf;
        } catch (Exception e) {
            return new byte[count];
        }
    }

    public long readLong(long address) {
        return ByteBuffer.wrap(readBytes(address, 8))
                .order(ByteOrder.LITTLE_ENDIAN).getLong();
    }

    public int readInt(long address) {
        return ByteBuffer.wrap(readBytes(address, 4))
                .order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    public float readFloat(long address) {
        return ByteBuffer.wrap(readBytes(address, 4))
                .order(ByteOrder.LITTLE_ENDIAN).getFloat();
    }

    /**
     * IL2CPP managed string: klass*(8) | monitor*(8) | length(4) | UTF-16LE chars
     */
    public String readString(long strPtr) {
        if (strPtr == 0) return "";
        try {
            int length = readInt(strPtr + 0x10);
            if (length <= 0 || length > 512) return "";
            byte[] charBytes = readBytes(strPtr + 0x14, length * 2);
            return new String(charBytes, "UTF-16LE");
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * C# List<T>: header(0x10) | _items array*(0x10) | _size(0x18)
     * array: header(0x20) | T[0](8) | T[1](8) | ...
     */
    public long readListElement(long listPtr, int index) {
        if (listPtr == 0) return 0;
        long itemsPtr = readLong(listPtr + 0x10);
        int  size     = readInt (listPtr + 0x18);
        if (index < 0 || index >= size || itemsPtr == 0) return 0;
        return readLong(itemsPtr + 0x20 + (long) index * 8);
    }

    public int readListSize(long listPtr) {
        if (listPtr == 0) return 0;
        return readInt(listPtr + 0x18);
    }

    // ------------------------------------------------------------------ //
    //  Offsets — verified against dump_1_13_11915                         //
    // ------------------------------------------------------------------ //

    // PlayerManager static fields
    static final long OFF_STATIC_CLIENT_LIST = 0x10L;  // clientPlayerList

    // PlayerManager instance fields
    static final long OFF_PM_FPMANAGER   = 0x90L;
    static final long OFF_PM_VITALS      = 0xC8L;
    static final long OFF_PM_NICKLABEL   = 0x130L;
    static final long OFF_PM_CHAR_MODEL  = 0x150L;
    static final long OFF_PM_DISPLAY_NAME= 0x220L;  // protected string LWQ
    static final long OFF_PM_USERID      = 0x278L;
    static final long OFF_PM_TEAMNAME    = 0x280L;

    // GenericVitals (parent of PlayerVitals)
    static final long OFF_VITALS_MAX_HEALTH = 0x88L;   // m_MaxHealth
    static final long OFF_VITALS_CUR_HEALTH = 0xB8L;   // Ljs (current health)

    // oh (nicklabel) -> nickname (Text) at 0x38 -> m_Text string at 0xC0
    static final long OFF_NICKLABEL_TEXTCOMP = 0x38L;
    static final long OFF_TEXT_MTEXT         = 0xC0L;

    // MonoBehaviour native pointer
    static final long OFF_MONOBEHAVIOUR_PTR = 0x10L;

    // Transform native position
    static final long OFF_TRANSFORM_POS = 0x90L;

    // FPManager -> Camera
    static final long OFF_FPM_WORLD_CAM = 0x20L;  // m_WorldCamera

    public float[] readTransformPosition(long transformManaged) {
        if (transformManaged == 0) return new float[]{0, 0, 0};
        long nativePtr = readLong(transformManaged + OFF_MONOBEHAVIOUR_PTR);
        if (nativePtr == 0) return new float[]{0, 0, 0};
        float x = readFloat(nativePtr + OFF_TRANSFORM_POS);
        float y = readFloat(nativePtr + OFF_TRANSFORM_POS + 4);
        float z = readFloat(nativePtr + OFF_TRANSFORM_POS + 8);
        return new float[]{x, y, z};
    }

    /**
     * Read nickname via nicklabel -> Text component -> m_Text string
     * oh.nickname (Text) is at 0x38, Text.m_Text (string) at 0xC0
     */
    public String readNickname(long nicklabelPtr) {
        if (nicklabelPtr == 0) return "";
        long textComponentPtr = readLong(nicklabelPtr + OFF_NICKLABEL_TEXTCOMP);
        if (textComponentPtr == 0) return "";
        long stringPtr = readLong(textComponentPtr + OFF_TEXT_MTEXT);
        return readString(stringPtr);
    }

    /**
     * Fallback: read displayName directly from PlayerManager.LWQ (0x220)
     */
    public String readDisplayName(long pmPtr) {
        if (pmPtr == 0) return "";
        long strPtr = readLong(pmPtr + OFF_PM_DISPLAY_NAME);
        return readString(strPtr);
    }

    public void close() {
        try { if (memFile != null) memFile.close(); } catch (Exception ignored) {}
        memFile = null;
    }
}
