package com.oxidesp.cheat;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads Oxide Survival Island game state via MemReader.
 * Called every ~50ms from ESPView update().
 *
 * FIXES vs original:
 *  1. resolveSymbol() now also scans r--p map entries (not just r-xp)
 *  2. resolveStaticList() retries listObjPtr if null (game still loading)
 *  3. readPlayerInfo() uses dual fallback for name (displayName → nicklabel → userID)
 *  4. findLocalPlayer() re-runs every frame to handle reconnect/respawn
 */
public class GameState {

    private static final String TAG = "OxideESP_State";

    // Verified against dump_1_13_11915 / script.json
    private static final long   TYPEINFO_STATIC_OFFSET = 0xB8L;
    private static final String TYPEINFO_SYMBOL        = "Oxide_PlayerManager_TypeInfo";
    // Address from script.json: Oxide.PlayerManager_TypeInfo = 0xD8DB8B8
    private static final long   FALLBACK_TYPEINFO_RVA  = 0xD8DB8B8L;

    public static class PlayerInfo {
        public String  name     = "";
        public String  team     = "";
        public float   health   = 0f;
        public float   maxHP    = 100f;
        public float   worldX, worldY, worldZ;
        public float   screenX, screenY;
        public boolean visible  = false;
        public float   distance = 0f;
        public boolean isLocalPlayer = false;
        // debug only
        long  _dbgPmPtr;
        long  _dbgVitalsPtr;
        float _dbgRawHealth;
        float _dbgRawMaxHP;
    }

    private final MemReader mem;
    private long staticListAddr = 0;
    private long localPlayerPtr = 0;
    private long cameraPtr      = 0;
    private float[] vpMatrix    = new float[16];

    public final List<PlayerInfo> players = new ArrayList<>();
    public DebugInfo dbg;

    public GameState(MemReader mem) {
        this.mem = mem;
    }

    // ------------------------------------------------------------------ //
    //  Init                                                                //
    // ------------------------------------------------------------------ //

    public boolean init(int pid) { return init(pid, null); }

    public boolean init(int pid, DebugInfo debugInfo) {
        this.dbg = debugInfo;
        staticListAddr = 0;
        cameraPtr      = 0;
        localPlayerPtr = 0;

        staticListAddr = resolveStaticList(pid);
        if (staticListAddr == 0) {
            Log.e(TAG, "Could not resolve clientPlayerList");
            return false;
        }
        if (dbg != null)
            dbg.stepListPtr.ok("0x" + Long.toHexString(staticListAddr).toUpperCase());
        Log.d(TAG, String.format("clientPlayerList @ 0x%X", staticListAddr));
        return true;
    }

    private long resolveStaticList(int pid) {
        long il2cppBase = mem.getIl2CppBase();
        if (il2cppBase == 0) return 0;

        // Step 1: ELF symbol scan
        long typeInfoAddr = resolveSymbol(pid, TYPEINFO_SYMBOL);

        if (dbg != null) {
            if (typeInfoAddr != 0)
                dbg.stepSymbol.ok(TYPEINFO_SYMBOL);
            else
                dbg.stepSymbol.warn("not in .dynsym — using RVA");
        }

        // Step 2: Fallback RVA (confirmed in script.json for v1.13.11915)
        if (typeInfoAddr == 0) {
            Log.w(TAG, "Symbol not found, using RVA 0x" + Long.toHexString(FALLBACK_TYPEINFO_RVA));
            typeInfoAddr = il2cppBase + FALLBACK_TYPEINFO_RVA;
            long sanity = mem.readLong(typeInfoAddr);
            if (sanity == 0 || sanity < il2cppBase) {
                Log.e(TAG, "RVA sanity fail val=0x" + Long.toHexString(sanity));
                if (dbg != null)
                    dbg.stepTypeInfo.fail("RVA sanity FAIL (0x" + Long.toHexString(sanity).toUpperCase() + ")");
                return 0;
            }
            if (dbg != null)
                dbg.stepTypeInfo.warn("0x" + Long.toHexString(typeInfoAddr).toUpperCase() + " (RVA)");
        } else {
            if (dbg != null)
                dbg.stepTypeInfo.ok("0x" + Long.toHexString(typeInfoAddr).toUpperCase());
        }

        // TypeInfo + 0xB8 → static_fields ptr
        long staticFieldsPtr = mem.readLong(typeInfoAddr + TYPEINFO_STATIC_OFFSET);
        if (staticFieldsPtr == 0) {
            Log.e(TAG, "staticFieldsPtr is null — game not initialised yet");
            if (dbg != null) dbg.stepStaticFields.fail("null — wait for game to load");
            return 0;
        }
        if (dbg != null)
            dbg.stepStaticFields.ok("0x" + Long.toHexString(staticFieldsPtr).toUpperCase());

        // static_fields + 0x10 → List<PlayerManager> clientPlayerList object
        long listObjPtr = mem.readLong(staticFieldsPtr + MemReader.OFF_STATIC_CLIENT_LIST);
        if (listObjPtr == 0) {
            Log.e(TAG, "clientPlayerList ptr null — game loading?");
            if (dbg != null) dbg.stepListPtr.fail("null — game loading, retry…");
            return 0;
        }
        return listObjPtr;
    }

    private long resolveSymbol(int pid, String symbolName) {
        try {
            String libPath = null;
            BufferedReader maps = new BufferedReader(
                    new InputStreamReader(
                            new java.io.FileInputStream("/proc/" + pid + "/maps")));
            String line;
            while ((line = maps.readLine()) != null) {
                if (line.contains("libil2cpp.so")
                        && (line.contains("r-xp") || line.contains("r--p"))) {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length >= 6) { libPath = parts[5]; break; }
                }
            }
            maps.close();
            if (libPath == null) return 0;
            return parseElfSymbol(libPath, symbolName, mem.getIl2CppBase());
        } catch (Exception e) {
            Log.e(TAG, "resolveSymbol: " + e.getMessage());
            return 0;
        }
    }

    private long parseElfSymbol(String libPath, String symName, long base) {
        try (java.io.RandomAccessFile elf = new java.io.RandomAccessFile(libPath, "r")) {
            byte[] hdr = new byte[64];
            elf.read(hdr);
            java.nio.ByteBuffer h = java.nio.ByteBuffer.wrap(hdr)
                    .order(java.nio.ByteOrder.LITTLE_ENDIAN);
            if (h.get(0) != 0x7F || h.get(1) != 'E') return 0;

            long  shoff   = h.getLong(0x28);
            short shentsz = h.getShort(0x3A);
            short shnum   = h.getShort(0x3C);

            long dynSymOff = 0, dynSymSz = 0;
            long dynStrOff = 0, dynStrSz = 0;

            for (int i = 0; i < shnum; i++) {
                elf.seek(shoff + (long) i * shentsz);
                byte[] shbuf = new byte[64];
                elf.read(shbuf);
                java.nio.ByteBuffer sh = java.nio.ByteBuffer.wrap(shbuf)
                        .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int  sh_type = sh.getInt(0x04);
                long sh_off  = sh.getLong(0x18);
                long sh_sz   = sh.getLong(0x20);
                int  sh_link = sh.getInt(0x28);

                if (sh_type == 11) { // SHT_DYNSYM
                    dynSymOff = sh_off;
                    dynSymSz  = sh_sz;
                    elf.seek(shoff + (long) sh_link * shentsz);
                    byte[] strbuf = new byte[64];
                    elf.read(strbuf);
                    java.nio.ByteBuffer strsh = java.nio.ByteBuffer.wrap(strbuf)
                            .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                    dynStrOff = strsh.getLong(0x18);
                    dynStrSz  = strsh.getLong(0x20);
                }
            }
            if (dynSymOff == 0) return 0;

            elf.seek(dynStrOff);
            byte[] strTable = new byte[(int) dynStrSz];
            elf.read(strTable);

            long symCount = dynSymSz / 24;
            for (long i = 0; i < symCount; i++) {
                elf.seek(dynSymOff + i * 24);
                byte[] sym = new byte[24];
                elf.read(sym);
                java.nio.ByteBuffer s = java.nio.ByteBuffer.wrap(sym)
                        .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int  nameOff = s.getInt(0);
                long value   = s.getLong(8);
                if (value == 0) continue;

                StringBuilder sb = new StringBuilder();
                for (int j = nameOff; j < strTable.length && strTable[j] != 0; j++)
                    sb.append((char) strTable[j]);

                if (sb.toString().equals(symName)) {
                    return base + value;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "ELF parse: " + e.getMessage());
        }
        return 0;
    }

    // ------------------------------------------------------------------ //
    //  Per-frame update                                                    //
    // ------------------------------------------------------------------ //

    public void update() {
        players.clear();
        if (staticListAddr == 0) return;

        int count = mem.readListSize(staticListAddr);
        if (count <= 0 || count > 200) {
            if (dbg != null) {
                dbg.playerCount  = 0;
                dbg.visibleCount = 0;
                dbg.listSize     = Math.max(0, count);
            }
            return;
        }
        if (dbg != null) dbg.listSize = count;

        updateCameraMatrix();

        List<DebugInfo.PlayerDebugEntry> newDbgList =
                (dbg != null) ? new ArrayList<>() : null;

        int visible = 0;
        for (int i = 0; i < count; i++) {
            long pmPtr = mem.readListElement(staticListAddr, i);
            if (pmPtr == 0) continue;

            PlayerInfo p = new PlayerInfo();
            p._dbgPmPtr = pmPtr;
            readPlayerInfo(pmPtr, p);
            projectToScreen(p);
            players.add(p);
            if (p.visible) visible++;

            if (newDbgList != null) {
                DebugInfo.PlayerDebugEntry entry = new DebugInfo.PlayerDebugEntry();
                entry.pmPtr     = pmPtr;
                entry.vitalsPtr = p._dbgVitalsPtr;
                entry.name      = p.name;
                entry.rawHealth = p._dbgRawHealth;
                entry.rawMaxHP  = p._dbgRawMaxHP;
                entry.worldX    = p.worldX;
                entry.worldY    = p.worldY;
                entry.worldZ    = p.worldZ;
                entry.screenX   = p.screenX;
                entry.screenY   = p.screenY;
                entry.distance  = p.distance;
                entry.visible   = p.visible;
                newDbgList.add(entry);
            }
        }

        if (dbg != null) {
            dbg.playerCount     = players.size();
            dbg.visibleCount    = visible;
            dbg.playerDebugList = newDbgList;
            dbg.camStatus       = (cameraPtr != 0)
                    ? "0x" + Long.toHexString(cameraPtr).toUpperCase()
                    : "not found";
            dbg.tickFrame();
        }
    }

    private void readPlayerInfo(long pmPtr, PlayerInfo p) {
        // Name: try displayName (LWQ @ 0x220) first, then nicklabel, then userID
        long nameStrPtr = mem.readLong(pmPtr + MemReader.OFF_PM_DISPLAY_NAME);
        if (nameStrPtr != 0) p.name = mem.readString(nameStrPtr);

        if (p.name.isEmpty()) {
            long nicklabelPtr = mem.readLong(pmPtr + MemReader.OFF_PM_NICKLABEL);
            if (nicklabelPtr != 0) p.name = mem.readNickname(nicklabelPtr);
        }
        if (p.name.isEmpty()) {
            long uidPtr = mem.readLong(pmPtr + MemReader.OFF_PM_USERID);
            if (uidPtr != 0) p.name = mem.readString(uidPtr);
        }

        // Team name
        long teamPtr = mem.readLong(pmPtr + MemReader.OFF_PM_TEAMNAME);
        if (teamPtr != 0) p.team = mem.readString(teamPtr);

        // Vitals — health from GenericVitals offsets (confirmed in dump)
        long vitalsPtr = mem.readLong(pmPtr + MemReader.OFF_PM_VITALS);
        p._dbgVitalsPtr = vitalsPtr;
        if (vitalsPtr != 0) {
            float rawMaxHP  = mem.readFloat(vitalsPtr + MemReader.OFF_VITALS_MAX_HEALTH);
            float rawHealth = mem.readFloat(vitalsPtr + MemReader.OFF_VITALS_CUR_HEALTH);
            p._dbgRawMaxHP  = rawMaxHP;
            p._dbgRawHealth = rawHealth;
            p.maxHP  = (rawMaxHP  > 0 && rawMaxHP  <= 1000) ? rawMaxHP  : 100f;
            p.health = Math.max(0f, Math.min(rawHealth, p.maxHP));
        }

        // World position: prefer nicklabel.character transform (most stable)
        long nicklabelPtr = mem.readLong(pmPtr + MemReader.OFF_PM_NICKLABEL);
        if (nicklabelPtr != 0) {
            long charTransform = mem.readLong(nicklabelPtr + 0x30L); // oh.character
            if (charTransform != 0) {
                float[] pos = mem.readTransformPosition(charTransform);
                p.worldX = pos[0]; p.worldY = pos[1]; p.worldZ = pos[2];
            }
        }

        // Fallback: GameObject characterModel transform
        if (p.worldX == 0f && p.worldZ == 0f) {
            long charModel = mem.readLong(pmPtr + MemReader.OFF_PM_CHAR_MODEL);
            if (charModel != 0) {
                long tfManaged = mem.readLong(charModel + 0x28L);
                if (tfManaged != 0) {
                    float[] pos = mem.readTransformPosition(tfManaged);
                    p.worldX = pos[0]; p.worldY = pos[1]; p.worldZ = pos[2];
                }
            }
        }
    }

    // ------------------------------------------------------------------ //
    //  Camera                                                              //
    // ------------------------------------------------------------------ //

    private void updateCameraMatrix() {
        // Re-find camera every frame if it's been lost (respawn / reconnect)
        if (cameraPtr == 0) {
            long lp = findLocalPlayer();
            if (lp == 0) return;
            long fpm = mem.readLong(lp + MemReader.OFF_PM_FPMANAGER);
            if (fpm == 0) return;
            long camManaged = mem.readLong(fpm + MemReader.OFF_FPM_WORLD_CAM);
            if (camManaged == 0) return;
            cameraPtr = mem.readLong(camManaged + MemReader.OFF_MONOBEHAVIOUR_PTR);
            Log.d(TAG, String.format("Camera native ptr: 0x%X", cameraPtr));
        }
        if (cameraPtr == 0) return;

        float[] proj = new float[16];
        float[] view = new float[16];
        for (int i = 0; i < 16; i++) {
            proj[i] = mem.readFloat(cameraPtr + 0x168L + i * 4);
            view[i] = mem.readFloat(cameraPtr + 0x1A8L + i * 4);
        }

        // Sanity check: if projection matrix is all-zero, camera pointer is stale
        boolean nonzero = false;
        for (float v : proj) if (v != 0f) { nonzero = true; break; }
        if (!nonzero) {
            Log.w(TAG, "Camera matrix all-zero — stale ptr, resetting");
            cameraPtr = 0;
            return;
        }

        vpMatrix = multiply4x4(proj, view);
    }

    private long findLocalPlayer() {
        if (staticListAddr == 0) return 0;
        int count = mem.readListSize(staticListAddr);
        for (int i = 0; i < Math.min(count, 200); i++) {
            long pmPtr = mem.readListElement(staticListAddr, i);
            if (pmPtr == 0) continue;
            long fpm = mem.readLong(pmPtr + MemReader.OFF_PM_FPMANAGER);
            if (fpm == 0) continue;
            long cam = mem.readLong(fpm + MemReader.OFF_FPM_WORLD_CAM);
            if (cam != 0) {
                localPlayerPtr = pmPtr;
                return pmPtr;
            }
        }
        return 0;
    }

    private float localX = 0f, localZ = 0f;

    private void projectToScreen(PlayerInfo p) {
        float wx = p.worldX, wy = p.worldY + 1.7f, wz = p.worldZ;

        float cx = vpMatrix[0]*wx  + vpMatrix[1]*wy  + vpMatrix[2]*wz  + vpMatrix[3];
        float cy = vpMatrix[4]*wx  + vpMatrix[5]*wy  + vpMatrix[6]*wz  + vpMatrix[7];
        float cw = vpMatrix[12]*wx + vpMatrix[13]*wy + vpMatrix[14]*wz + vpMatrix[15];

        if (cw <= 0.01f) { p.visible = false; return; }

        float ndcX =  cx / cw;
        float ndcY = -cy / cw;

        p.screenX = (ndcX + 1f) * 0.5f;
        p.screenY = (ndcY + 1f) * 0.5f;
        p.visible = (p.screenX >= -0.1f && p.screenX <= 1.1f &&
                     p.screenY >= -0.1f && p.screenY <= 1.1f);

        // Update local player position for distance calculation
        if (localPlayerPtr != 0) {
            long nlPtr = mem.readLong(localPlayerPtr + MemReader.OFF_PM_NICKLABEL);
            if (nlPtr != 0) {
                long tf = mem.readLong(nlPtr + 0x30L);
                if (tf != 0) {
                    float[] lpos = mem.readTransformPosition(tf);
                    localX = lpos[0]; localZ = lpos[2];
                }
            }
        }

        float dx = p.worldX - localX, dz = p.worldZ - localZ;
        p.distance = (float) Math.sqrt(dx * dx + dz * dz);
    }

    private static float[] multiply4x4(float[] a, float[] b) {
        float[] r = new float[16];
        for (int row = 0; row < 4; row++)
            for (int col = 0; col < 4; col++)
                for (int k = 0; k < 4; k++)
                    r[row * 4 + col] += a[row * 4 + k] * b[k * 4 + col];
        return r;
    }
}
