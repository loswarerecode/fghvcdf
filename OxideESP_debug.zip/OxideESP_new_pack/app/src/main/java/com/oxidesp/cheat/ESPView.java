package com.oxidesp.cheat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.View;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ESPView extends View {

    private static final String TAG       = "OxideESP_View";
    private static final int    UPDATE_MS = 50;

    // ── Settings ───────────────────────────────────────────────────────
    boolean espEnabled     = true;
    boolean showNames      = true;
    boolean showHealth     = true;
    boolean showDistance   = true;
    boolean showBox        = true;
    boolean showTeam       = false;
    boolean showSkeleton   = false;
    boolean showLines      = false;
    int     maxEspDistance = 300;

    // ── State ──────────────────────────────────────────────────────────
    private final Context ctx;
    private WindowManager wm;
    private WindowManager.LayoutParams overlayParams;
    GameState    gameState;
    private MemReader    memReader;
    DebugInfo    debugInfo;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread updateThread;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    // Init retry state
    private volatile boolean initScheduled = false;
    private static final int INIT_RETRY_DELAY_MODULES_MS = 4000; // wait for .so to load
    private static final int INIT_RETRY_DELAY_GAMESTATE_MS = 5000;
    private static final int PID_RETRY_DELAY_MS = 3000;

    private int screenW, screenH;

    // ── Gear / Menu ────────────────────────────────────────────────────
    float   gearX = 60f, gearY = 200f;
    boolean menuOpen      = false;
    boolean debugMenuOpen = false;

    private static final float GEAR_RADIUS    = 38f;
    private static final float MENU_W         = 300f;
    private static final float MENU_ROW       = 52f;
    private static final float MENU_PADDING   = 16f;

    private static final String[] MENU_LABELS = {
            "ESP ON/OFF", "Box", "Skeleton", "Lines",
            "Names", "Health bar", "Distance", "Max Dist"
    };

    // ── Paints ─────────────────────────────────────────────────────────
    private final Paint pBox      = new Paint();
    private final Paint pBoxFill  = new Paint();
    private final Paint pName     = new Paint();
    private final Paint pHealth   = new Paint();
    private final Paint pHealthBg = new Paint();
    private final Paint pMenu     = new Paint();
    private final Paint pMenuHdr  = new Paint();
    private final Paint pMenuTxt  = new Paint();
    private final Paint pLine     = new Paint();
    private final Paint pDivider  = new Paint();
    private final Paint pDbgOk    = new Paint();
    private final Paint pDbgFail  = new Paint();
    private final Paint pDbgWarn  = new Paint();
    private final Paint pDbgGray  = new Paint();
    private final Paint pDbgVal   = new Paint();
    private final Paint pStatusBg = new Paint();

    // ── Constructor ────────────────────────────────────────────────────
    public ESPView(Context context) {
        super(context);
        this.ctx = context;
        setLayerType(LAYER_TYPE_HARDWARE, null);
        initPaints();
        debugInfo = new DebugInfo();
        scheduleInit(0);
    }

    public void setWindowManager(WindowManager wm, WindowManager.LayoutParams params) {
        this.wm = wm;
        this.overlayParams = params;
    }

    void enableTouch(boolean enable) {
        if (wm == null || overlayParams == null) return;
        if (enable) overlayParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else        overlayParams.flags |=  WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { wm.updateViewLayout(this, overlayParams); } catch (Exception ignored) {}
    }

    // ── Paints init ────────────────────────────────────────────────────
    private void initPaints() {
        pBox.setStyle(Paint.Style.STROKE);
        pBox.setStrokeWidth(2.5f);
        pBox.setAntiAlias(true);

        pBoxFill.setStyle(Paint.Style.FILL);
        pBoxFill.setColor(Color.argb(30, 255, 50, 50));

        pName.setTextSize(28f);
        pName.setTypeface(Typeface.DEFAULT_BOLD);
        pName.setAntiAlias(true);
        pName.setShadowLayer(4f, 1f, 1f, Color.BLACK);

        pHealth.setStyle(Paint.Style.FILL);
        pHealth.setAntiAlias(true);

        pHealthBg.setStyle(Paint.Style.FILL);
        pHealthBg.setColor(Color.argb(180, 30, 30, 30));

        pMenu.setStyle(Paint.Style.FILL);
        pMenu.setColor(Color.argb(225, 12, 14, 26));
        pMenu.setAntiAlias(true);

        pMenuHdr.setTextSize(24f);
        pMenuHdr.setTypeface(Typeface.MONOSPACE);
        pMenuHdr.setAntiAlias(true);
        pMenuHdr.setFakeBoldText(true);

        pMenuTxt.setTextSize(27f);
        pMenuTxt.setAntiAlias(true);
        pMenuTxt.setTypeface(Typeface.MONOSPACE);

        pLine.setStyle(Paint.Style.STROKE);
        pLine.setStrokeWidth(1.5f);
        pLine.setAntiAlias(true);

        pDivider.setStyle(Paint.Style.STROKE);
        pDivider.setStrokeWidth(1f);
        pDivider.setColor(Color.argb(80, 80, 160, 255));
        pDivider.setAntiAlias(true);

        pDbgOk.setTextSize(22f);   pDbgOk.setAntiAlias(true);   pDbgOk.setTypeface(Typeface.MONOSPACE);
        pDbgOk.setColor(Color.argb(255, 50, 220, 90));

        pDbgFail.setTextSize(22f); pDbgFail.setAntiAlias(true); pDbgFail.setTypeface(Typeface.MONOSPACE);
        pDbgFail.setColor(Color.argb(255, 255, 60, 60));

        pDbgWarn.setTextSize(22f); pDbgWarn.setAntiAlias(true); pDbgWarn.setTypeface(Typeface.MONOSPACE);
        pDbgWarn.setColor(Color.argb(255, 255, 190, 40));

        pDbgGray.setTextSize(22f); pDbgGray.setAntiAlias(true); pDbgGray.setTypeface(Typeface.MONOSPACE);
        pDbgGray.setColor(Color.argb(160, 180, 180, 180));

        pDbgVal.setTextSize(20f);  pDbgVal.setAntiAlias(true);  pDbgVal.setTypeface(Typeface.MONOSPACE);
        pDbgVal.setColor(Color.argb(200, 140, 200, 255));

        pStatusBg.setStyle(Paint.Style.FILL);
        pStatusBg.setAntiAlias(true);
    }

    // ── Game init ──────────────────────────────────────────────────────

    private void scheduleInit(long delayMs) {
        if (initScheduled) return;
        initScheduled = true;
        uiHandler.postDelayed(() -> {
            initScheduled = false;
            initGame();
        }, delayMs);
    }

    void initGame() {
        new Thread(() -> {
            try {
                // Step 1: find PID — retry until the game process appears
                int pid = 0;
                for (int attempt = 0; attempt < 60; attempt++) {
                    pid = findGamePid();
                    if (pid != 0) break;
                    debugInfo.stepPid.warn("searching… (attempt " + (attempt + 1) + ")");
                    postInvalidate();
                    Thread.sleep(PID_RETRY_DELAY_MS);
                }

                if (pid == 0) {
                    debugInfo.stepPid.fail("game not found — is it running in GBox?");
                    postInvalidate();
                    scheduleInit(PID_RETRY_DELAY_MS);
                    return;
                }
                debugInfo.stepPid.ok(String.valueOf(pid));
                postInvalidate();

                // Step 2: open mem and find .so bases
                // Retry until libil2cpp.so appears in maps (game may still be loading)
                if (memReader != null) { memReader.close(); memReader = null; }

                boolean memOk = false;
                for (int attempt = 0; attempt < 30; attempt++) {
                    // Reset debug steps for retry display
                    if (attempt > 0) {
                        debugInfo.stepMemOpen.value = "retrying…";
                        debugInfo.stepIl2Cpp.value  = "…";
                        postInvalidate();
                    }

                    MemReader mr = new MemReader(pid);
                    if (mr.init(debugInfo)) {
                        memReader = mr;
                        memOk = true;
                        break;
                    } else {
                        mr.close();
                    }
                    postInvalidate();

                    // Check if the PID is still alive before retrying
                    if (!isPidAlive(pid)) {
                        Log.w(TAG, "pid " + pid + " died, restarting init");
                        debugInfo.stepPid.warn("process died");
                        scheduleInit(2000);
                        return;
                    }

                    Thread.sleep(INIT_RETRY_DELAY_MODULES_MS);
                }

                if (!memOk) {
                    debugInfo.stepMemOpen.fail("failed after retries");
                    postInvalidate();
                    scheduleInit(INIT_RETRY_DELAY_MODULES_MS);
                    return;
                }
                postInvalidate();

                // Step 3: resolve game state (TypeInfo, static list, etc.)
                gameState = new GameState(memReader);
                boolean gsOk = false;
                for (int attempt = 0; attempt < 10; attempt++) {
                    if (gameState.init(pid, debugInfo)) {
                        gsOk = true;
                        break;
                    }
                    postInvalidate();

                    if (!isPidAlive(pid)) {
                        scheduleInit(2000);
                        return;
                    }
                    Thread.sleep(INIT_RETRY_DELAY_GAMESTATE_MS);
                }

                if (!gsOk) {
                    postInvalidate();
                    scheduleInit(INIT_RETRY_DELAY_GAMESTATE_MS);
                    return;
                }

                postInvalidate();
                if (!running.get()) startUpdating();

            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
            } catch (Exception e) {
                Log.e(TAG, "initGame exception: " + e.getMessage());
                scheduleInit(5000);
            }
        }, "ESP-Init").start();
    }

    /**
     * Scan /proc for the Oxide game process.
     * Checks: com.oxide, oxide.survival, hyperhug, oxide (cmdline contains any of these)
     */
    private int findGamePid() {
        try {
            java.io.File[] procs = new java.io.File("/proc").listFiles();
            if (procs == null) return 0;
            for (java.io.File f : procs) {
                String name = f.getName();
                // Only numeric dirs
                boolean isNum = true;
                for (char c : name.toCharArray()) {
                    if (c < '0' || c > '9') { isNum = false; break; }
                }
                if (!isNum || name.isEmpty()) continue;

                java.io.File cmdFile = new java.io.File(f, "cmdline");
                if (!cmdFile.exists()) continue;
                try {
                    java.io.FileInputStream fis = new java.io.FileInputStream(cmdFile);
                    byte[] buf = new byte[256];
                    int len = fis.read(buf);
                    fis.close();
                    if (len <= 0) continue;
                    // cmdline is null-terminated, first token is package name
                    String cmdline = new String(buf, 0, len).split("\0")[0].toLowerCase();
                    if (cmdline.contains("oxide")
                            || cmdline.contains("hyperhug")
                            || cmdline.contains("survival.island")) {
                        int pid = Integer.parseInt(name);
                        Log.d(TAG, "Found game pid=" + pid + " cmdline=" + cmdline);
                        return pid;
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            Log.e(TAG, "findPid: " + e.getMessage());
        }
        return 0;
    }

    /** Check if a PID directory still exists in /proc */
    private boolean isPidAlive(int pid) {
        return new java.io.File("/proc/" + pid).exists();
    }

    // ── Update thread ──────────────────────────────────────────────────
    public void startUpdating() {
        if (running.getAndSet(true)) return;
        updateThread = new Thread(() -> {
            while (running.get()) {
                try {
                    if (gameState != null) {
                        gameState.update();
                        postInvalidate();
                    }
                    Thread.sleep(UPDATE_MS);
                } catch (InterruptedException e) {
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "update: " + e.getMessage());
                }
            }
        }, "ESP-Update");
        updateThread.setDaemon(true);
        updateThread.start();
    }

    public void stopUpdating() {
        running.set(false);
        if (updateThread != null) updateThread.interrupt();
        if (memReader != null) memReader.close();
    }

    // ── Draw ───────────────────────────────────────────────────────────
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        screenW = w; screenH = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (screenW == 0 || screenH == 0) return;

        if (espEnabled && gameState != null) {
            List<GameState.PlayerInfo> snap = new java.util.ArrayList<>(gameState.players);
            for (GameState.PlayerInfo p : snap) {
                if (!p.visible)                  continue;
                if (p.isLocalPlayer)             continue;
                if (p.distance > maxEspDistance) continue;
                drawPlayer(canvas, p);
            }
        }

        drawStartupStatus(canvas);

        if (menuOpen)      drawSettingsMenu(canvas);
        if (debugMenuOpen) drawDebugMenu(canvas);
    }

    // ── ESP drawing ────────────────────────────────────────────────────
    private void drawPlayer(Canvas canvas, GameState.PlayerInfo p) {
        float sx = p.screenX * screenW;
        float sy = p.screenY * screenH;

        float boxH = Math.max(20f, Math.min(600f, screenH * 1.8f / Math.max(1f, p.distance)));
        float boxW = boxH * 0.4f;

        float top    = sy;
        float bottom = sy + boxH;
        float left   = sx - boxW / 2f;
        float right  = sx + boxW / 2f;

        float hpFrac = Math.min(1f, Math.max(0f, p.health / Math.max(1f, p.maxHP)));
        int   r      = (int)((1f - hpFrac) * 255);
        int   g      = (int)(hpFrac * 220);
        int   hpColor = Color.rgb(r, g, 40);

        if (showBox) {
            pBox.setColor(hpColor);
            canvas.drawRect(left, top, right, bottom, pBox);
        }

        if (showHealth) {
            float barX = left - 8f;
            float barH = bottom - top;
            canvas.drawRect(barX - 4f, top, barX, bottom, pHealthBg);
            pHealth.setColor(hpColor);
            canvas.drawRect(barX - 4f, top + barH * (1f - hpFrac), barX, bottom, pHealth);
        }

        if (showLines) {
            pLine.setColor(hpColor);
            canvas.drawLine(screenW / 2f, screenH, sx, sy + boxH / 2f, pLine);
        }

        float textY = top - 4f;
        if (showNames && !p.name.isEmpty()) {
            pName.setColor(Color.WHITE);
            float tw = pName.measureText(p.name);
            canvas.drawText(p.name, sx - tw / 2f, textY, pName);
            textY -= 30f;
        }

        if (showDistance) {
            String distStr = (int) p.distance + "m";
            pName.setTextSize(22f);
            pName.setColor(Color.argb(200, 180, 220, 255));
            float tw = pName.measureText(distStr);
            canvas.drawText(distStr, sx - tw / 2f, textY, pName);
            pName.setTextSize(28f);
        }
    }

    // ── Status overlay ─────────────────────────────────────────────────
    private void drawStartupStatus(Canvas canvas) {
        if (debugInfo == null) return;
        boolean fullyInit = debugInfo.isFullyInit();
        if (fullyInit && !debugMenuOpen) return;

        // Top-right status chip
        String statusText;
        int chipColor;
        if (fullyInit) {
            statusText = "● MEM:OK  PID:" + debugInfo.stepPid.value;
            chipColor  = Color.argb(200, 20, 160, 60);
        } else {
            statusText = "● MEM:FAIL  PID:" + debugInfo.stepPid.value;
            chipColor  = Color.argb(220, 180, 20, 20);
        }

        Paint chipPaint = new Paint(pStatusBg);
        chipPaint.setColor(chipColor);
        float chipW  = 340f;
        float chipH  = 44f;
        float chipX  = screenW - chipW - 8f;
        float chipY  = 8f;
        canvas.drawRoundRect(new RectF(chipX, chipY, chipX + chipW, chipY + chipH), 10, 10, chipPaint);

        pDbgOk.setTextSize(20f);
        Paint tp = fullyInit ? pDbgOk : pDbgFail;
        canvas.drawText(statusText, chipX + 10f, chipY + 30f, tp);
        pDbgOk.setTextSize(22f);
    }

    // ── Debug menu ─────────────────────────────────────────────────────
    private void drawDebugMenu(Canvas canvas) {
        if (debugInfo == null) return;
        float x = 20f, y = 50f, w = 520f, rowH = 32f;

        List<DebugInfo.Step> steps = debugInfo.initSteps();
        float totalH = MENU_PADDING * 2 + 40f + steps.size() * rowH + 10f
                + 5 * rowH + 10f;

        pStatusBg.setColor(Color.argb(220, 8, 10, 20));
        canvas.drawRoundRect(new RectF(x, y, x + w, y + totalH), 14, 14, pStatusBg);

        float tx = x + MENU_PADDING, ty = y + MENU_PADDING;

        pMenuHdr.setColor(Color.argb(255, 100, 180, 255));
        canvas.drawText("[ OxideESP — Debug ]", tx, ty + 28f, pMenuHdr);
        ty += 44f;

        canvas.drawLine(tx, ty, tx + w - MENU_PADDING * 2, ty, pDivider);
        ty += 12f;

        for (DebugInfo.Step step : steps) {
            Paint lbl;
            String indicator;
            switch (step.status) {
                case OK:   lbl = pDbgOk;   indicator = "✓"; break;
                case FAIL: lbl = pDbgFail; indicator = "✗"; break;
                case WARN: lbl = pDbgWarn; indicator = "!"; break;
                default:   lbl = pDbgGray; indicator = "…"; break;
            }
            canvas.drawText(indicator + " " + step.label, tx, ty + 22f, lbl);
            canvas.drawText(step.value, tx + 220f, ty + 22f, pDbgVal);
            ty += rowH;
        }

        ty += 8f;
        canvas.drawLine(tx, ty, tx + w - MENU_PADDING * 2, ty, pDivider);
        ty += 12f;

        pDbgGray.setColor(Color.argb(200, 160, 200, 255));
        canvas.drawText("Players: " + debugInfo.playerCount
                + "  Visible: " + debugInfo.visibleCount, tx, ty + 22f, pDbgGray);
        ty += rowH;
        canvas.drawText("List size: " + debugInfo.listSize, tx, ty + 22f, pDbgGray);
        ty += rowH;
        canvas.drawText("Camera: " + debugInfo.camStatus, tx, ty + 22f, pDbgGray);
        ty += rowH;
        canvas.drawText("Update: " + debugInfo.updateHz + " Hz", tx, ty + 22f, pDbgGray);
        ty += rowH;

        // Player raw data
        List<DebugInfo.PlayerDebugEntry> dbgList = debugInfo.playerDebugList;
        if (dbgList != null && !dbgList.isEmpty()) {
            DebugInfo.PlayerDebugEntry e = dbgList.get(0);
            canvas.drawText(String.format("P0: %.0f/%.0fhp  dist=%.1fm",
                    e.rawHealth, e.rawMaxHP, e.distance), tx, ty + 22f, pDbgGray);
        }

        pDbgGray.setColor(Color.argb(160, 180, 180, 180));
    }

    // ── Settings menu ──────────────────────────────────────────────────
    private void drawSettingsMenu(Canvas canvas) {
        float x = gearX - MENU_W / 2f;
        float y = gearY + GEAR_RADIUS + 8f;
        float totalH = MENU_PADDING * 2 + 38f + MENU_LABELS.length * MENU_ROW;

        if (x + MENU_W > screenW - 10) x = screenW - MENU_W - 10;
        if (x < 10) x = 10;

        pStatusBg.setColor(Color.argb(230, 10, 12, 24));
        canvas.drawRoundRect(new RectF(x, y, x + MENU_W, y + totalH), 16, 16, pStatusBg);

        pMenuHdr.setColor(Color.argb(255, 80, 160, 255));
        canvas.drawText("OxideESP", x + MENU_PADDING, y + MENU_PADDING + 26f, pMenuHdr);

        float itemY = y + MENU_PADDING + 46f;
        boolean[] states = {espEnabled, showBox, showSkeleton, showLines,
                showNames, showHealth, showDistance, false};

        for (int i = 0; i < MENU_LABELS.length; i++) {
            boolean on = (i < states.length) && states[i];
            if (i == MENU_LABELS.length - 1) {
                pMenuTxt.setColor(Color.argb(200, 160, 160, 200));
                canvas.drawText("Dist: " + maxEspDistance + "m",
                        x + MENU_PADDING, itemY + 34f, pMenuTxt);
            } else {
                pMenuTxt.setColor(on
                        ? Color.argb(255, 50, 220, 120)
                        : Color.argb(180, 180, 180, 180));
                canvas.drawText((on ? "● " : "○ ") + MENU_LABELS[i],
                        x + MENU_PADDING, itemY + 34f, pMenuTxt);
            }
            itemY += MENU_ROW;
        }
    }

    // ── Touch (delegated from GearButtonView) ──────────────────────────
    void onMenuToggle() {
        menuOpen = !menuOpen;
        debugMenuOpen = false;
        enableTouch(menuOpen);
        postInvalidate();
    }

    void onDebugToggle() {
        debugMenuOpen = !debugMenuOpen;
        menuOpen = false;
        enableTouch(debugMenuOpen);
        postInvalidate();
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!menuOpen && !debugMenuOpen) return false;

        if (event.getAction() == MotionEvent.ACTION_DOWN) {
            float tx = event.getX(), ty = event.getY();

            // Close on tap outside menus
            float menuX = gearX - MENU_W / 2f;
            float menuY = gearY + GEAR_RADIUS + 8f;
            float menuH = MENU_PADDING * 2 + 38f + MENU_LABELS.length * MENU_ROW;

            boolean inMenu = (tx >= menuX && tx <= menuX + MENU_W
                    && ty >= menuY && ty <= menuY + menuH);

            if (!inMenu) {
                menuOpen = false;
                debugMenuOpen = false;
                enableTouch(false);
                postInvalidate();
                return true;
            }

            // Handle menu row taps
            if (menuOpen) {
                float itemY = menuY + MENU_PADDING + 46f;
                for (int i = 0; i < MENU_LABELS.length; i++) {
                    if (ty >= itemY && ty <= itemY + MENU_ROW) {
                        onMenuItemTap(i);
                        break;
                    }
                    itemY += MENU_ROW;
                }
            }
        }
        return true;
    }

    private void onMenuItemTap(int idx) {
        switch (idx) {
            case 0: espEnabled   = !espEnabled;   break;
            case 1: showBox      = !showBox;       break;
            case 2: showSkeleton = !showSkeleton;  break;
            case 3: showLines    = !showLines;     break;
            case 4: showNames    = !showNames;     break;
            case 5: showHealth   = !showHealth;    break;
            case 6: showDistance = !showDistance;  break;
            case 7:
                maxEspDistance = (maxEspDistance >= 500) ? 50 : maxEspDistance + 50;
                break;
        }
        postInvalidate();
    }
}
