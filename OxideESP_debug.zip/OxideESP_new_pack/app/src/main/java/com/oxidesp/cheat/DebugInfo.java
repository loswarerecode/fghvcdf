package com.oxidesp.cheat;

import java.util.ArrayList;
import java.util.List;

/**
 * Хранит всю отладочную информацию о том, что чит читает из памяти.
 * Заполняется на этапе инициализации и обновляется в каждом кадре.
 */
public class DebugInfo {

    public enum Status { PENDING, OK, FAIL, WARN }

    // ── Сырые данные одного игрока из памяти (обновляются каждый тик) ─
    public static class PlayerDebugEntry {
        public long    pmPtr;       // адрес PlayerManager в куче
        public long    vitalsPtr;   // адрес VitalsComponent
        public String  name        = "";
        public float   rawHealth;   // float до зажима
        public float   rawMaxHP;    // float до зажима
        public float   worldX, worldY, worldZ;
        public float   screenX, screenY;
        public float   distance;
        public boolean visible;
    }

    public static class Step {
        public final String label;
        public String value  = "…";
        public Status status = Status.PENDING;

        public Step(String label) { this.label = label; }

        public Step ok(String val)   { value = val; status = Status.OK;   return this; }
        public Step fail(String val) { value = val; status = Status.FAIL; return this; }
        public Step warn(String val) { value = val; status = Status.WARN; return this; }
    }

    // ── Init pipeline (заполняется один раз при старте) ────────────────
    public final Step stepPid          = new Step("Game PID");
    public final Step stepMemOpen      = new Step("/proc/pid/mem");
    public final Step stepIl2Cpp       = new Step("libil2cpp base");
    public final Step stepUnity        = new Step("libunity base");
    public final Step stepSymbol       = new Step("TypeInfo symbol");
    public final Step stepTypeInfo     = new Step("TypeInfo addr");
    public final Step stepStaticFields = new Step("static_fields ptr");
    public final Step stepListPtr      = new Step("clientPlayerList");

    // ── Runtime (обновляется каждый тик) ──────────────────────────────
    public volatile int    playerCount  = 0;
    public volatile int    visibleCount = 0;
    public volatile String camStatus    = "not found";
    public volatile int    updateHz     = 0;
    /** Сырой размер списка из памяти (до фильтрации) */
    public volatile int    listSize     = 0;
    /** Снимок сырых данных каждого игрока за последний тик */
    public volatile List<PlayerDebugEntry> playerDebugList = new ArrayList<>();

    private long _hzWindow = 0;
    private int  _frames   = 0;

    public void tickFrame() {
        _frames++;
        long now = System.currentTimeMillis();
        if (now - _hzWindow >= 1000) {
            updateHz  = _frames;
            _frames   = 0;
            _hzWindow = now;
        }
    }

    public List<Step> initSteps() {
        List<Step> out = new ArrayList<>();
        out.add(stepPid);
        out.add(stepMemOpen);
        out.add(stepIl2Cpp);
        out.add(stepUnity);
        out.add(stepSymbol);
        out.add(stepTypeInfo);
        out.add(stepStaticFields);
        out.add(stepListPtr);
        return out;
    }

    public boolean isFullyInit() {
        return stepPid.status     == Status.OK
            && stepIl2Cpp.status  == Status.OK
            && stepListPtr.status == Status.OK;
    }
}
