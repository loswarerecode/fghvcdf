package com.oxidesp.cheat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/**
 * Маленький draggable оверлей с двумя кнопками:
 *  ⚙  (тап)       — открыть/закрыть Settings меню
 *  🔍 (долгий тап) — открыть/закрыть Debug меню
 *
 * Перетаскивание работает при удержании > DRAG_THRESHOLD пикселей.
 */
public class GearButtonView extends View {

    private static final float GEAR_RADIUS    = 38f;
    private static final float DRAG_THRESHOLD = 12f;
    private static final long  LONG_PRESS_MS  = 400L;
    private static final int   SIZE           = (int)(GEAR_RADIUS * 2 + 40);

    private final ESPView espView;
    private WindowManager wm;
    private WindowManager.LayoutParams params;

    private float dragStartX, dragStartY;
    private boolean isDragging  = false;
    private long    downTime    = 0L;

    private final Paint pBg     = new Paint();
    private final Paint pBorder = new Paint();
    private final Paint pTxt    = new Paint();
    private final Paint pDot    = new Paint();
    private final Paint pDbgDot = new Paint();

    public GearButtonView(Context context, ESPView espView) {
        super(context);
        this.espView = espView;
        setLayerType(LAYER_TYPE_HARDWARE, null);

        pBg.setAntiAlias(true);
        pBg.setStyle(Paint.Style.FILL);

        pBorder.setAntiAlias(true);
        pBorder.setStyle(Paint.Style.STROKE);
        pBorder.setStrokeWidth(2.5f);

        pTxt.setColor(Color.WHITE);
        pTxt.setTextSize(34f);
        pTxt.setAntiAlias(true);
        pTxt.setTextAlign(Paint.Align.CENTER);

        pDot.setAntiAlias(true);
        pDot.setStyle(Paint.Style.FILL);

        pDbgDot.setAntiAlias(true);
        pDbgDot.setStyle(Paint.Style.FILL);
    }

    public void setWindowManager(WindowManager wm, WindowManager.LayoutParams params) {
        this.wm     = wm;
        this.params = params;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = SIZE / 2f;
        float cy = SIZE / 2f;

        // Цвет фона зависит от того, какое меню открыто
        int bgColor;
        if (espView.debugMenuOpen) {
            bgColor = Color.argb(230, 180, 80, 0);   // оранжевый — debug открыт
        } else if (espView.menuOpen) {
            bgColor = Color.argb(230, 40, 120, 255);  // синий — settings открыт
        } else {
            bgColor = Color.argb(200, 20, 22, 40);    // тёмный — закрыто
        }
        pBg.setColor(bgColor);
        canvas.drawCircle(cx, cy, GEAR_RADIUS, pBg);

        // Рамка: синяя/оранжевая
        pBorder.setColor(espView.debugMenuOpen
                ? Color.argb(255, 255, 160, 40)
                : Color.argb(255, 80, 160, 255));
        canvas.drawCircle(cx, cy, GEAR_RADIUS, pBorder);

        // Иконка
        if (espView.debugMenuOpen) {
            pTxt.setTextSize(30f);
            canvas.drawText("🔍", cx, cy + 11f, pTxt);
        } else {
            pTxt.setTextSize(34f);
            canvas.drawText("⚙", cx, cy + 12f, pTxt);
        }

        // Зелёный/красный статус-дот (верхний правый угол)
        boolean active = espView.gameState != null && espView.espEnabled;
        pDot.setColor(active
                ? Color.argb(255, 50, 255, 80)
                : Color.argb(255, 255, 60, 60));
        canvas.drawCircle(cx + GEAR_RADIUS - 9f, cy - GEAR_RADIUS + 9f, 7f, pDot);

        // Маленький синий дот снизу — индикатор debug-меню
        if (espView.debugInfo != null && espView.debugInfo.isFullyInit()) {
            pDbgDot.setColor(Color.argb(200, 80, 180, 255));
            canvas.drawCircle(cx - GEAR_RADIUS + 9f, cy + GEAR_RADIUS - 9f, 5f, pDbgDot);
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float tx = e.getX(), ty = e.getY();
        switch (e.getActionMasked()) {

            case MotionEvent.ACTION_DOWN:
                dragStartX  = tx;
                dragStartY  = ty;
                isDragging  = false;
                downTime    = System.currentTimeMillis();
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = tx - dragStartX;
                float dy = ty - dragStartY;
                if (!isDragging && Math.sqrt(dx * dx + dy * dy) > DRAG_THRESHOLD) {
                    isDragging = true;
                }
                if (isDragging && wm != null) {
                    params.x += (int) dx;
                    params.y += (int) dy;
                    dragStartX = tx;
                    dragStartY = ty;
                    wm.updateViewLayout(this, params);
                    espView.gearX = params.x + SIZE / 2f;
                    espView.gearY = params.y + SIZE / 2f;
                    espView.postInvalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
                if (!isDragging) {
                    long held = System.currentTimeMillis() - downTime;
                    if (held >= LONG_PRESS_MS) {
                        // Долгий тап → Debug меню
                        espView.menuOpen      = false;
                        espView.debugMenuOpen = !espView.debugMenuOpen;
                    } else {
                        // Короткий тап → Settings меню
                        espView.debugMenuOpen = false;
                        espView.menuOpen      = !espView.menuOpen;
                    }
                    espView.enableTouch(espView.menuOpen || espView.debugMenuOpen);
                    espView.postInvalidate();
                }
                isDragging = false;
                postInvalidate();
                return true;
        }
        return false;
    }
}
