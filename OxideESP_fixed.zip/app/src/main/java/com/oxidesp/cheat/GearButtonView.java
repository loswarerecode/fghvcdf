package com.oxidesp.cheat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/**
 * Small draggable gear button overlay.
 * Separate from ESPView so it can be touchable while ESP overlay is NOT_TOUCHABLE.
 * Tapping opens/closes the settings panel in ESPView.
 */
public class GearButtonView extends View {

    private static final float GEAR_RADIUS    = 38f;
    private static final float DRAG_THRESHOLD = 12f;
    private static final int   SIZE           = (int)(GEAR_RADIUS * 2 + 40);

    private final ESPView espView;
    private WindowManager wm;
    private WindowManager.LayoutParams params;

    private float dragStartX, dragStartY;
    private boolean isDragging = false;

    private final Paint paintBg   = new Paint();
    private final Paint paintBorder = new Paint();
    private final Paint paintTxt  = new Paint();
    private final Paint paintDot  = new Paint();

    public GearButtonView(Context context, ESPView espView) {
        super(context);
        this.espView = espView;
        setLayerType(LAYER_TYPE_HARDWARE, null);

        paintBg.setAntiAlias(true);
        paintBg.setStyle(Paint.Style.FILL);

        paintBorder.setAntiAlias(true);
        paintBorder.setStyle(Paint.Style.STROKE);
        paintBorder.setStrokeWidth(2f);
        paintBorder.setColor(Color.argb(255, 80, 180, 255));

        paintTxt.setColor(Color.WHITE);
        paintTxt.setTextSize(36f);
        paintTxt.setAntiAlias(true);
        paintTxt.setTextAlign(Paint.Align.CENTER);

        paintDot.setAntiAlias(true);
        paintDot.setStyle(Paint.Style.FILL);
    }

    public void setWindowManager(WindowManager wm, WindowManager.LayoutParams params) {
        this.wm = wm;
        this.params = params;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float cx = SIZE / 2f;
        float cy = SIZE / 2f;

        // Background circle
        paintBg.setColor(espView.menuOpen
                ? Color.argb(230, 40, 120, 255)
                : Color.argb(200, 30, 30, 50));
        canvas.drawCircle(cx, cy, GEAR_RADIUS, paintBg);
        canvas.drawCircle(cx, cy, GEAR_RADIUS, paintBorder);

        // ⚙ icon
        canvas.drawText("⚙", cx, cy + 13f, paintTxt);

        // Status dot
        boolean active = espView.gameState != null && espView.espEnabled;
        paintDot.setColor(active
                ? Color.argb(255, 50, 255, 80)
                : Color.argb(255, 255, 60, 60));
        canvas.drawCircle(cx + GEAR_RADIUS - 8f, cy - GEAR_RADIUS + 8f, 7f, paintDot);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float tx = e.getX(), ty = e.getY();
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                dragStartX = tx; dragStartY = ty;
                isDragging = false;
                return true;

            case MotionEvent.ACTION_MOVE:
                float dx = tx - dragStartX;
                float dy = ty - dragStartY;
                if (!isDragging && Math.sqrt(dx*dx + dy*dy) > DRAG_THRESHOLD) {
                    isDragging = true;
                }
                if (isDragging && wm != null) {
                    params.x += (int) dx;
                    params.y += (int) dy;
                    dragStartX = tx;
                    dragStartY = ty;
                    wm.updateViewLayout(this, params);
                    // Синхронизируем позицию шестерни в ESPView для рисования меню
                    espView.gearX = params.x + SIZE / 2f;
                    espView.gearY = params.y + SIZE / 2f;
                    espView.postInvalidate();
                }
                return true;

            case MotionEvent.ACTION_UP:
                if (!isDragging) {
                    // Тап — переключить меню
                    espView.menuOpen = !espView.menuOpen;
                    espView.enableTouch(espView.menuOpen);
                    espView.postInvalidate();
                }
                isDragging = false;
                postInvalidate();
                return true;
        }
        return false;
    }
}
