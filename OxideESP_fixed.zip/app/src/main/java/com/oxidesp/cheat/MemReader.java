package com.oxidesp.cheat;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * Non-root memory reader using /proc/<pid>/mem.
 * Works in GBox — same UID shared with the game process.
 * All reads are little-endian (ARM64 Android).
 */
public class MemReader {

    private static final String TAG = "OxideESP_Mem";

    private final int targetPid;
    private RandomAccessFile memFile;
    private long il2cppBase;
    private long unityBase;

    public MemReader(int pid) {
        this.targetPid = pid;
    }

    // ------------------------------------------------------------------ //
    //  Init                                                                //
    // ------------------------------------------------------------------ //

    public boolean init() {
        try {
            // FIX: открываем /proc/pid/mem в режиме "rw" — на некоторых
            // версиях Android "r" бросает исключение при seek > 2GB.
            // GBox даёт нам тот же UID что у игры, поэтому доступ есть.
            try {
                memFile = new RandomAccessFile("/proc/" + targetPid + "/mem", "rw");
            } catch (Exception e) {
                // fallback — только чтение
                memFile = new RandomAccessFile("/proc/" + targetPid + "/mem", "r");
            }
            il2cppBase = findModuleBase("libil2cpp.so");
            unityBase  = findModuleBase("libunity.so");
            if (il2cppBase == 0 || unityBase == 0) {
                Log.e(TAG, "Could not find module bases");
                return false;
            }
            Log.d(TAG, String.format("il2cpp=0x%X  unity=0x%X", il2cppBase, unityBase));
            return true;
        } catch (Exception e) {
            Log.e(TAG, "init failed: " + e.getMessage());
            return false;
        }
    }

    public long findModuleBase(String libName) {
        try {
            RandomAccessFile maps = new RandomAccessFile(
                    "/proc/" + targetPid + "/maps", "r");
            String line;
            while ((line = maps.readLine()) != null) {
                if (line.contains(libName) && line.contains("r-xp")) {
                    String addrRange = line.split("-")[0];
                    maps.close();
                    return Long.parseLong(addrRange, 16);
                }
            }
            maps.close();
        } catch (IOException e) {
            Log.e(TAG, "maps error: " + e.getMessage());
        }
        return 0L;
    }

    public long getIl2CppBase() { return il2cppBase; }
    public long getUnityBase()  { return unityBase;  }

    // ------------------------------------------------------------------ //
    //  Primitive reads                                                     //
    // ------------------------------------------------------------------ //

    public byte[] readBytes(long address, int count) {
        if (memFile == null || address <= 0) return new byte[count];
        try {
            byte[] buf = new byte[count];
            memFile.seek(address);
            int total = 0;
            while (total < count) {
                int n = memFile.read(buf, total, count - total);
                if (n <= 0) break;
                total += n;
            }
            return buf;
        } catch (Exception e) {
            return new byte[count];
        }
    }

    public long readLong(long address) {
        return ByteBuffer.wrap(readBytes(address, 8))
                .order(ByteOrder.LITTLE_ENDIAN).getLong();
    }

    public int readInt(long address) {
        return ByteBuffer.wrap(readBytes(address, 4))
                .order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    public float readFloat(long address) {
        return ByteBuffer.wrap(readBytes(address, 4))
                .order(ByteOrder.LITTLE_ENDIAN).getFloat();
    }

    /**
     * IL2CPP managed string: klass*(8) | monitor*(8) | length(4) | UTF-16LE chars
     */
    public String readString(long strPtr) {
        if (strPtr == 0) return "";
        try {
            int length = readInt(strPtr + 0x10);
            if (length <= 0 || length > 512) return "";
            byte[] charBytes = readBytes(strPtr + 0x14, length * 2);
            return new String(charBytes, "UTF-16LE");
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * C# List<T>: header(0x10) | _items array*(0x10) | _size(0x18)
     * array: header(0x20) | T[0](8) | T[1](8) | ...
     */
    public long readListElement(long listPtr, int index) {
        if (listPtr == 0) return 0;
        long itemsPtr = readLong(listPtr + 0x10);
        int  size     = readInt (listPtr + 0x18);
        if (index < 0 || index >= size || itemsPtr == 0) return 0;
        return readLong(itemsPtr + 0x20 + (long) index * 8);
    }

    public int readListSize(long listPtr) {
        if (listPtr == 0) return 0;
        return readInt(listPtr + 0x18);
    }

    // ------------------------------------------------------------------ //
    //  Offsets (verified against dump_1_13_11915)                        //
    // ------------------------------------------------------------------ //

    // PlayerManager static fields
    static final long OFF_STATIC_CLIENT_LIST = 0x10L; // clientPlayerList в static block

    // PlayerManager instance fields
    static final long OFF_PM_FPMANAGER   = 0x90L;   // FPManager*
    static final long OFF_PM_VITALS      = 0xC8L;   // PlayerVitals*
    static final long OFF_PM_NICKLABEL   = 0x130L;  // oh (NickLabel MonoBehaviour)*
    static final long OFF_PM_USERID      = 0x278L;  // string userID
    static final long OFF_PM_TEAMNAME    = 0x280L;  // string teamName
    static final long OFF_PM_CHAR_MODEL  = 0x150L;  // GameObject* characterModel
    static final long OFF_PM_DISPLAY_NAME= 0x220L;  // string LWQ (display name)

    // GenericVitals (base класс PlayerVitals)
    static final long OFF_VITALS_MAX_HEALTH = 0x88L; // float m_MaxHealth
    static final long OFF_VITALS_CUR_HEALTH = 0xB8L; // float Ljs (current HP)

    // oh (NickLabel) fields — FIX: было 0x30 (Transform*), должно быть 0x38 (Text*)
    static final long OFF_NICKLABEL_TEXT = 0x38L; // Text* nickname

    // MonoBehaviour/Component → native ptr
    static final long OFF_MONOBEHAVIOUR_PTR = 0x10L; // m_CachedPtr (intptr_t)

    // Native UnityEngine::Transform → Vector3 position
    static final long OFF_TRANSFORM_POS = 0x90L;

    // FPManager → Camera
    static final long OFF_FPM_WORLD_CAM = 0x20L; // Camera* m_WorldCamera

    // Text → string m_Text (вычислено по il2cpp.h layout)
    // Il2CppObject header(0x10) + Text fields offset of m_Text
    static final long OFF_TEXT_MTEXT = 0xC0L; // System.String* m_Text в объекте Text

    /**
     * Читает мировую позицию из managed Transform объекта.
     * Transform → m_CachedPtr (0x10) → native ptr → position @ 0x90
     */
    public float[] readTransformPosition(long transformManaged) {
        if (transformManaged == 0) return new float[]{0, 0, 0};
        long nativePtr = readLong(transformManaged + OFF_MONOBEHAVIOUR_PTR);
        if (nativePtr == 0) return new float[]{0, 0, 0};
        float x = readFloat(nativePtr + OFF_TRANSFORM_POS);
        float y = readFloat(nativePtr + OFF_TRANSFORM_POS + 4);
        float z = readFloat(nativePtr + OFF_TRANSFORM_POS + 8);
        return new float[]{x, y, z};
    }

    /**
     * Читает nickname из NickLabel (oh объект).
     * oh + 0x38 → Text* → m_Text (System.String*)
     */
    public String readNickname(long nicklabelPtr) {
        if (nicklabelPtr == 0) return "";
        long textComponentPtr = readLong(nicklabelPtr + OFF_NICKLABEL_TEXT);
        if (textComponentPtr == 0) return "";
        long stringPtr = readLong(textComponentPtr + OFF_TEXT_MTEXT);
        return readString(stringPtr);
    }

    public void close() {
        try { if (memFile != null) memFile.close(); } catch (Exception ignored) {}
    }
}
