package com.oxidesp.cheat;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Читает состояние игры Oxide Survival Island через MemReader.
 * Вызывается каждые ~50 мс из ESPView.update().
 *
 * Цепочка поиска clientPlayerList:
 *   1. ELF .dynsym scan → ищем "Oxide_PlayerManager_TypeInfo"
 *   2. Fallback: ARM64 ADRP decode по RVA функции get_clientPlayerList
 *   3. TypeInfo + 0xB8 → static_fields_ptr
 *   4. static_fields_ptr + 0x10 → List<PlayerManager> object ptr
 */
public class GameState {

    private static final String TAG = "OxideESP_State";

    // Offset static_fields ptr внутри Il2CppClass (Il2CppClass_1 size = 0xB8)
    private static final long TYPEINFO_STATIC_OFFSET = 0xB8L;

    // FIX #1: Правильное имя символа — "Oxide_PlayerManager_TypeInfo"
    // (не "PlayerManager_TypeInfo" — в Oxide namespace)
    private static final String TYPEINFO_SYMBOL = "Oxide_PlayerManager_TypeInfo";

    // Fallback RVA: PlayerManager$$get_clientPlayerList из dump_1_13_11915
    // script.json: ScriptMethod с именем содержащим clientPlayerList / static
    // Из dump: public static readonly List<PlayerManager> clientPlayerList; // 0x10
    // RVA функции которая возвращает clientPlayerList (из script.json addresses):
    private static final long FALLBACK_TYPEINFO_RVA = 0xD8DB8B8L; // Oxide_PlayerManager_TypeInfo VA offset

    public static class PlayerInfo {
        public String  name     = "";
        public String  team     = "";
        public float   health   = 0f;
        public float   maxHP    = 100f;
        public float   worldX, worldY, worldZ;
        public float   screenX, screenY;
        public boolean visible  = false;
        public float   distance = 0f;
        public boolean isLocalPlayer = false;
    }

    private final MemReader mem;
    private long staticListAddr = 0;
    private long localPlayerPtr = 0;
    private float[] vpMatrix = new float[16];

    public final List<PlayerInfo> players = new ArrayList<>();

    public GameState(MemReader mem) {
        this.mem = mem;
    }

    // ------------------------------------------------------------------ //
    //  Init                                                                //
    // ------------------------------------------------------------------ //

    public boolean init(int pid) {
        staticListAddr = resolveStaticList(pid);
        if (staticListAddr == 0) {
            Log.e(TAG, "Could not resolve clientPlayerList");
            return false;
        }
        Log.d(TAG, String.format("clientPlayerList @ 0x%X", staticListAddr));
        return true;
    }

    private long resolveStaticList(int pid) {
        long il2cppBase = mem.getIl2CppBase();
        if (il2cppBase == 0) return 0;

        // Шаг 1: ELF symbol scan по правильному имени
        long typeInfoAddr = resolveSymbol(pid, TYPEINFO_SYMBOL);

        // Шаг 2: Fallback — прямой адрес из script.json
        // В script.json: Oxide_PlayerManager_TypeInfo address = 227391672 = 0xD8DB8B8
        // Это file-VA (адрес при загрузке с base=0).
        // В памяти: il2cppBase + FALLBACK_TYPEINFO_RVA
        if (typeInfoAddr == 0) {
            Log.w(TAG, "Symbol not found, trying compiled RVA approach");
            typeInfoAddr = il2cppBase + FALLBACK_TYPEINFO_RVA;
            // Проверяем что по этому адресу что-то разумное (klass ptr не ноль)
            long sanityCheck = mem.readLong(typeInfoAddr);
            if (sanityCheck == 0 || sanityCheck < il2cppBase) {
                Log.e(TAG, "RVA fallback sanity check failed");
                typeInfoAddr = 0;
            }
        }

        if (typeInfoAddr == 0) return 0;

        // TypeInfo + 0xB8 → static_fields_ptr
        long staticFieldsPtr = mem.readLong(typeInfoAddr + TYPEINFO_STATIC_OFFSET);
        if (staticFieldsPtr == 0) {
            Log.e(TAG, "staticFieldsPtr is null");
            return 0;
        }

        // static_fields:
        //   +0x00  sleepingPlayerList (MB<PlayerManager>*)
        //   +0x08  activePlayerList   (MB<PlayerManager>*)
        //   +0x10  clientPlayerList   (List<PlayerManager>*)  ← нам нужно это
        //   +0x18  serverName
        //   +0x20  serverBuildNumber
        long listObjPtr = mem.readLong(staticFieldsPtr + 0x10);
        if (listObjPtr == 0) {
            Log.e(TAG, "clientPlayerList ptr is null — game not fully loaded yet?");
            return 0;
        }
        return listObjPtr;
    }

    /**
     * ELF64 symbol scan: парсим .dynsym libil2cpp.so чтобы найти адрес символа.
     */
    private long resolveSymbol(int pid, String symbolName) {
        try {
            String libPath = null;
            BufferedReader maps = new BufferedReader(
                    new InputStreamReader(
                            new java.io.FileInputStream("/proc/" + pid + "/maps")));
            String line;
            while ((line = maps.readLine()) != null) {
                if (line.contains("libil2cpp.so") && line.contains("r-xp")) {
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length >= 6) { libPath = parts[5]; break; }
                }
            }
            maps.close();
            if (libPath == null) return 0;
            return parseElfSymbol(libPath, symbolName, mem.getIl2CppBase());
        } catch (Exception e) {
            Log.e(TAG, "resolveSymbol: " + e.getMessage());
            return 0;
        }
    }

    private long parseElfSymbol(String libPath, String symName, long base) {
        try (java.io.RandomAccessFile elf = new java.io.RandomAccessFile(libPath, "r")) {
            byte[] hdr = new byte[64];
            elf.read(hdr);
            java.nio.ByteBuffer h = java.nio.ByteBuffer.wrap(hdr)
                    .order(java.nio.ByteOrder.LITTLE_ENDIAN);
            if (h.get(0) != 0x7F || h.get(1) != 'E') return 0;

            long  shoff    = h.getLong(0x28);
            short shentsz  = h.getShort(0x3A);
            short shnum    = h.getShort(0x3C);

            long dynSymOff = 0, dynSymSz = 0;
            long dynStrOff = 0, dynStrSz = 0;

            for (int i = 0; i < shnum; i++) {
                elf.seek(shoff + (long) i * shentsz);
                byte[] shbuf = new byte[64];
                elf.read(shbuf);
                java.nio.ByteBuffer sh = java.nio.ByteBuffer.wrap(shbuf)
                        .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int  sh_type = sh.getInt(0x04);
                long sh_off  = sh.getLong(0x18);
                long sh_sz   = sh.getLong(0x20);
                int  sh_link = sh.getInt(0x28);

                if (sh_type == 11 /* SHT_DYNSYM */) {
                    dynSymOff = sh_off;
                    dynSymSz  = sh_sz;
                    elf.seek(shoff + (long) sh_link * shentsz);
                    byte[] strbuf = new byte[64];
                    elf.read(strbuf);
                    java.nio.ByteBuffer strsh = java.nio.ByteBuffer.wrap(strbuf)
                            .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                    dynStrOff = strsh.getLong(0x18);
                    dynStrSz  = strsh.getLong(0x20);
                }
            }
            if (dynSymOff == 0) return 0;

            elf.seek(dynStrOff);
            byte[] strTable = new byte[(int) dynStrSz];
            elf.read(strTable);

            // Elf64_Sym = 24 bytes
            long symCount = dynSymSz / 24;
            for (long i = 0; i < symCount; i++) {
                elf.seek(dynSymOff + i * 24);
                byte[] sym = new byte[24];
                elf.read(sym);
                java.nio.ByteBuffer s = java.nio.ByteBuffer.wrap(sym)
                        .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int  nameOff = s.getInt(0);
                long value   = s.getLong(8);
                if (value == 0) continue;

                StringBuilder sb = new StringBuilder();
                for (int j = nameOff; j < strTable.length && strTable[j] != 0; j++)
                    sb.append((char) strTable[j]);

                if (sb.toString().equals(symName)) {
                    // value — file VA, base — ASLR slide
                    return base + value;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "ELF parse: " + e.getMessage());
        }
        return 0;
    }

    // ------------------------------------------------------------------ //
    //  Per-frame update                                                    //
    // ------------------------------------------------------------------ //

    public void update() {
        players.clear();

        // FIX #3: если staticListAddr == 0, пробуем переинициализироваться
        if (staticListAddr == 0) {
            // Попытка найти pid заново и reinit не нужна здесь —
            // ESPView будет вызывать initGame повторно
            return;
        }

        int count = mem.readListSize(staticListAddr);
        if (count <= 0 || count > 200) return;

        updateCameraMatrix();

        for (int i = 0; i < count; i++) {
            long pmPtr = mem.readListElement(staticListAddr, i);
            if (pmPtr == 0) continue;

            PlayerInfo p = new PlayerInfo();
            readPlayerInfo(pmPtr, p);
            projectToScreen(p);
            players.add(p);
        }
    }

    private void readPlayerInfo(long pmPtr, PlayerInfo p) {
        // Имя: сначала пробуем displayName (LWQ @ 0x220), потом nickname через NickLabel
        long namePtr = mem.readLong(pmPtr + MemReader.OFF_PM_DISPLAY_NAME);
        if (namePtr != 0) p.name = mem.readString(namePtr);

        // FIX #2: читаем никнейм через NickLabel правильно (Text @ 0x38, не Transform @ 0x30)
        if (p.name.isEmpty()) {
            long nicklabelPtr = mem.readLong(pmPtr + MemReader.OFF_PM_NICKLABEL);
            if (nicklabelPtr != 0) p.name = mem.readNickname(nicklabelPtr);
        }

        // Fallback — userID (числовой, но хоть что-то)
        if (p.name.isEmpty()) {
            long uidPtr = mem.readLong(pmPtr + MemReader.OFF_PM_USERID);
            if (uidPtr != 0) p.name = mem.readString(uidPtr);
        }

        // Team
        long teamPtr = mem.readLong(pmPtr + MemReader.OFF_PM_TEAMNAME);
        if (teamPtr != 0) p.team = mem.readString(teamPtr);

        // HP
        long vitalsPtr = mem.readLong(pmPtr + MemReader.OFF_PM_VITALS);
        if (vitalsPtr != 0) {
            p.health = mem.readFloat(vitalsPtr + MemReader.OFF_VITALS_CUR_HEALTH);
            p.maxHP  = mem.readFloat(vitalsPtr + MemReader.OFF_VITALS_MAX_HEALTH);
            if (p.maxHP <= 0 || p.maxHP > 1000) p.maxHP = 100f;
            // Санитизация HP
            if (p.health < 0) p.health = 0;
            if (p.health > p.maxHP) p.health = p.maxHP;
        }

        // Позиция через NickLabel.character (Transform @ 0x30)
        // character — это Transform объект персонажа, 0x30 правильно для позиции
        long nicklabelPtr = mem.readLong(pmPtr + MemReader.OFF_PM_NICKLABEL);
        if (nicklabelPtr != 0) {
            // character Transform @ nicklabel + 0x30
            long charTransform = mem.readLong(nicklabelPtr + 0x30L);
            if (charTransform != 0) {
                float[] pos = mem.readTransformPosition(charTransform);
                p.worldX = pos[0]; p.worldY = pos[1]; p.worldZ = pos[2];
            }
        }

        // Если позиция нулевая — пробуем через characterModel
        if (p.worldX == 0 && p.worldZ == 0) {
            long charModel = mem.readLong(pmPtr + MemReader.OFF_PM_CHAR_MODEL);
            if (charModel != 0) {
                // GameObject → Transform ptr @ 0x28 (managed), затем нативный
                long tfManaged = mem.readLong(charModel + 0x28L);
                if (tfManaged != 0) {
                    float[] pos = mem.readTransformPosition(tfManaged);
                    p.worldX = pos[0]; p.worldY = pos[1]; p.worldZ = pos[2];
                }
            }
        }
    }

    // ------------------------------------------------------------------ //
    //  Camera                                                              //
    // ------------------------------------------------------------------ //

    private long cameraPtr = 0;

    private void updateCameraMatrix() {
        if (cameraPtr == 0) {
            long lp = findLocalPlayer();
            if (lp == 0) return;
            long fpm = mem.readLong(lp + MemReader.OFF_PM_FPMANAGER);
            if (fpm == 0) return;
            long camManaged = mem.readLong(fpm + MemReader.OFF_FPM_WORLD_CAM);
            if (camManaged == 0) return;
            cameraPtr = mem.readLong(camManaged + MemReader.OFF_MONOBEHAVIOUR_PTR);
            Log.d(TAG, String.format("Camera native ptr: 0x%X", cameraPtr));
        }
        if (cameraPtr == 0) return;

        // Unity Camera native layout (Unity 2021/2022 LTS ARM64):
        //   +0x168 : projectionMatrix (float[16])
        //   +0x1A8 : worldToCameraMatrix (float[16])
        float[] proj = new float[16];
        float[] view = new float[16];
        for (int i = 0; i < 16; i++) {
            proj[i] = mem.readFloat(cameraPtr + 0x168L + i * 4);
            view[i] = mem.readFloat(cameraPtr + 0x1A8L + i * 4);
        }
        vpMatrix = multiply4x4(proj, view);
    }

    private long findLocalPlayer() {
        if (staticListAddr == 0) return 0;
        int count = mem.readListSize(staticListAddr);
        for (int i = 0; i < Math.min(count, 200); i++) {
            long pmPtr = mem.readListElement(staticListAddr, i);
            if (pmPtr == 0) continue;
            long fpm = mem.readLong(pmPtr + MemReader.OFF_PM_FPMANAGER);
            if (fpm == 0) continue;
            long cam = mem.readLong(fpm + MemReader.OFF_FPM_WORLD_CAM);
            if (cam != 0) { localPlayerPtr = pmPtr; return pmPtr; }
        }
        return 0;
    }

    private float lx, lz;

    private void projectToScreen(PlayerInfo p) {
        float wx = p.worldX, wy = p.worldY + 1.7f, wz = p.worldZ;

        float cx  = vpMatrix[0]*wx + vpMatrix[1]*wy  + vpMatrix[2]*wz  + vpMatrix[3];
        float cy  = vpMatrix[4]*wx + vpMatrix[5]*wy  + vpMatrix[6]*wz  + vpMatrix[7];
        float cw  = vpMatrix[12]*wx+ vpMatrix[13]*wy + vpMatrix[14]*wz + vpMatrix[15];

        if (cw <= 0.01f) { p.visible = false; return; }

        float ndcX =  cx / cw;
        float ndcY = -cy / cw;

        p.screenX = (ndcX + 1f) * 0.5f;
        p.screenY = (ndcY + 1f) * 0.5f;
        p.visible = (p.screenX >= -0.1f && p.screenX <= 1.1f &&
                     p.screenY >= -0.1f && p.screenY <= 1.1f);

        if (localPlayerPtr != 0) {
            long nicklabelPtr = mem.readLong(localPlayerPtr + MemReader.OFF_PM_NICKLABEL);
            if (nicklabelPtr != 0) {
                long charTf = mem.readLong(nicklabelPtr + 0x30L);
                if (charTf != 0) {
                    float[] lpos = mem.readTransformPosition(charTf);
                    lx = lpos[0]; lz = lpos[2];
                }
            }
        }
        float dx = p.worldX - lx, dz = p.worldZ - lz;
        p.distance = (float) Math.sqrt(dx * dx + dz * dz);
    }

    private static float[] multiply4x4(float[] a, float[] b) {
        float[] r = new float[16];
        for (int row = 0; row < 4; row++)
            for (int col = 0; col < 4; col++)
                for (int k = 0; k < 4; k++)
                    r[row * 4 + col] += a[row * 4 + k] * b[k * 4 + col];
        return r;
    }
}
