package com.oxidesp.cheat;

import android.util.Log;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * Non-root memory reader using /proc/<pid>/mem
 * Works because GBox runs the game in the same user namespace —
 * we share the same UID, so ptrace/mem access is allowed.
 *
 * All reads are little-endian (ARM64 / x86 Android).
 */
public class MemReader {

    private static final String TAG = "OxideESP_Mem";

    private final int targetPid;
    private RandomAccessFile memFile;
    private long il2cppBase;   // libil2cpp.so base address
    private long unityBase;    // libunity.so base address

    public MemReader(int pid) {
        this.targetPid = pid;
    }

    // ------------------------------------------------------------------ //
    //  Initialization                                                      //
    // ------------------------------------------------------------------ //

    public boolean init() {
        try {
            memFile = new RandomAccessFile("/proc/" + targetPid + "/mem", "r");
            il2cppBase = findModuleBase("libil2cpp.so");
            unityBase  = findModuleBase("libunity.so");
            if (il2cppBase == 0 || unityBase == 0) {
                Log.e(TAG, "Could not find module bases");
                return false;
            }
            Log.d(TAG, String.format("il2cpp base: 0x%X  unity base: 0x%X",
                    il2cppBase, unityBase));
            return true;
        } catch (Exception e) {
            Log.e(TAG, "init failed: " + e.getMessage());
            return false;
        }
    }

    /**
     * Parse /proc/<pid>/maps and find the load address of a .so
     */
    public long findModuleBase(String libName) {
        try {
            RandomAccessFile maps = new RandomAccessFile(
                    "/proc/" + targetPid + "/maps", "r");
            String line;
            while ((line = maps.readLine()) != null) {
                if (line.contains(libName) && line.contains("r-xp")) {
                    // format: startAddr-endAddr perms offset dev inode path
                    String addrRange = line.split("-")[0];
                    maps.close();
                    return Long.parseLong(addrRange, 16);
                }
            }
            maps.close();
        } catch (IOException e) {
            Log.e(TAG, "maps read error: " + e.getMessage());
        }
        return 0L;
    }

    public long getIl2CppBase()  { return il2cppBase; }
    public long getUnityBase()   { return unityBase;  }

    // ------------------------------------------------------------------ //
    //  Primitive reads                                                     //
    // ------------------------------------------------------------------ //

    private byte[] readBytes(long address, int count) {
        if (memFile == null || address == 0) return new byte[count];
        try {
            byte[] buf = new byte[count];
            memFile.seek(address);
            int read = memFile.read(buf);
            if (read != count) return new byte[count];
            return buf;
        } catch (Exception e) {
            return new byte[count];
        }
    }

    public long readLong(long address) {
        byte[] b = readBytes(address, 8);
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getLong();
    }

    public int readInt(long address) {
        byte[] b = readBytes(address, 4);
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getInt();
    }

    public float readFloat(long address) {
        byte[] b = readBytes(address, 4);
        return ByteBuffer.wrap(b).order(ByteOrder.LITTLE_ENDIAN).getFloat();
    }

    public boolean readBool(long address) {
        byte[] b = readBytes(address, 1);
        return b[0] != 0;
    }

    /**
     * Read a Unity/IL2CPP managed string (UTF-16LE)
     * Layout: klass*(8) | monitor*(8) | length(4) | chars[length](2 each)
     */
    public String readString(long strPtr) {
        if (strPtr == 0) return "";
        try {
            int length = readInt(strPtr + 0x10);
            if (length <= 0 || length > 256) return "";
            byte[] charBytes = readBytes(strPtr + 0x14, length * 2);
            return new String(charBytes, "UTF-16LE");
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Read a C# List<T>:
     *   offset 0x10 → _items array ptr
     *   offset 0x18 → _size (count)
     *   array[0x20 + index * 8] → element ptr
     */
    public long readListElement(long listPtr, int index) {
        if (listPtr == 0) return 0;
        long itemsPtr = readLong(listPtr + 0x10);
        int  size     = readInt(listPtr  + 0x18);
        if (index < 0 || index >= size || itemsPtr == 0) return 0;
        return readLong(itemsPtr + 0x20 + (long) index * 8);
    }

    public int readListSize(long listPtr) {
        if (listPtr == 0) return 0;
        return readInt(listPtr + 0x18);
    }

    // ------------------------------------------------------------------ //
    //  High-level game reads using dump offsets                           //
    // ------------------------------------------------------------------ //

    /*
     * Oxide.PlayerManager layout (from dump_1_13_11915):
     *   static clientPlayerList → symbol in il2cpp data segment
     *
     * We locate the static field via the IL2CPP metadata:
     *   PlayerManager$$get_clientPlayerList is at RVA 0x636E2F8
     *   but easier: the static fields pointer is at a known offset
     *   from the Class object. We use the exported symbol approach:
     *
     *   In IL2CPP the static field storage for PlayerManager is found at
     *   PlayerManager_TypeInfo + 0xB8 (StaticFields ptr) → clientPlayerList at +0x10
     *
     *   TypeInfo is a global in libil2cpp.so which we resolve by scanning
     *   the symbol table — see findTypeInfo().
     */

    // Offset of clientPlayerList inside PlayerManager static fields block
    static final long OFF_STATIC_CLIENT_LIST = 0x10;

    // PlayerManager instance field offsets
    static final long OFF_PM_VITALS          = 0xC8;  // PlayerVitals*
    static final long OFF_PM_NICKLABEL       = 0x130; // oh*
    static final long OFF_PM_USERID          = 0x278; // string
    static final long OFF_PM_TEAMNAME        = 0x280; // string
    static final long OFF_PM_CHAR_MODEL      = 0x150; // GameObject*
    static final long OFF_PM_FPMANAGER       = 0x90;  // FPManager*

    // GenericVitals (base of PlayerVitals)
    static final long OFF_VITALS_CUR_HEALTH  = 0xB8;  // float Ljs
    static final long OFF_VITALS_MAX_HEALTH  = 0x88;  // float m_MaxHealth

    // oh (nicklabel : MonoBehaviour) → character Transform
    static final long OFF_NICKLABEL_CHAR     = 0x30;  // Transform*

    // Transform → position (UnityEngine.Transform internal)
    // In Unity 2021+ the Transform stores position in the TransformData
    // at offset 0x90 inside the internal native object.
    // MonoBehaviour (managed) → m_CachedPtr (native) at 0x10
    static final long OFF_MONOBEHAVIOUR_PTR  = 0x10;
    static final long OFF_TRANSFORM_POS      = 0x90;  // Vector3 (local, but world for root)

    // FPManager → m_WorldCamera (Camera*)
    static final long OFF_FPM_WORLD_CAM      = 0x20;

    /**
     * Read world position from a managed Transform object
     */
    public float[] readTransformPosition(long transformManaged) {
        if (transformManaged == 0) return new float[]{0, 0, 0};
        long nativePtr = readLong(transformManaged + OFF_MONOBEHAVIOUR_PTR);
        if (nativePtr == 0) return new float[]{0, 0, 0};
        float x = readFloat(nativePtr + OFF_TRANSFORM_POS);
        float y = readFloat(nativePtr + OFF_TRANSFORM_POS + 4);
        float z = readFloat(nativePtr + OFF_TRANSFORM_POS + 8);
        return new float[]{x, y, z};
    }

    public void close() {
        try { if (memFile != null) memFile.close(); } catch (Exception ignored) {}
    }
}
