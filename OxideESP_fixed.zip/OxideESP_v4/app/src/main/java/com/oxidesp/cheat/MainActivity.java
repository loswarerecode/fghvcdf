package com.oxidesp.cheat;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;

/**
 * Launcher activity.
 * 1. Request POST_NOTIFICATIONS (Android 13+).
 * 2. Check SYSTEM_ALERT_WINDOW permission (needed for overlay in GBox).
 * 3. Start ESPOverlayService.
 * 4. Minimize.
 *
 * No root required — overlay runs via TYPE_APPLICATION_OVERLAY which
 * GBox grants to apps inside the parallel space.
 */
public class MainActivity extends Activity {

    private static final int REQ_OVERLAY       = 1001;
    private static final int REQ_NOTIFICATION  = 1002;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Step 1: Request notification permission (Android 13+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQ_NOTIFICATION);
                return;
            }
        }

        // Step 2: Check overlay permission
        checkOverlayAndStart();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Continue regardless of notification permission result
        checkOverlayAndStart();
    }

    private void checkOverlayAndStart() {
        if (!Settings.canDrawOverlays(this)) {
            new AlertDialog.Builder(this)
                    .setTitle("OxideESP — Permission required")
                    .setMessage("Allow overlay permission so the ESP can draw on top of the game.\n\n" +
                            "Tap OK → find OxideESP in the list → enable 'Display over other apps'.\n\n" +
                            "In GBox: Settings → Apps → OxideESP → Display over other apps.")
                    .setPositiveButton("Open Settings", (d, w) -> {
                        Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(i, REQ_OVERLAY);
                    })
                    .setNegativeButton("Cancel", (d, w) -> finish())
                    .show();
        } else {
            startESP();
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                startESP();
            } else {
                Toast.makeText(this,
                        "Overlay permission denied — ESP cannot run.",
                        Toast.LENGTH_LONG).show();
                finish();
            }
        }
    }

    private void startESP() {
        Intent svc = new Intent(this, ESPOverlayService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        Toast.makeText(this, "OxideESP started! Launch Oxide Survival Island.", Toast.LENGTH_LONG).show();
        // Move to background — ESP runs as overlay
        moveTaskToBack(true);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Keep service running even if activity is destroyed
    }
}
