package com.oxidesp.cheat;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;

/**
 * Oxide Survival Island - ESP Overlay Service
 * Runs as a floating overlay (non-root, via GBox parallel space)
 *
 * IMPORTANT for GBox (no root):
 *   - Uses TYPE_APPLICATION_OVERLAY — GBox grants this inside its parallel space
 *   - Must call startForeground() immediately on Android 8+ or OS kills the service
 *   - No mediaProjection foregroundServiceType — overlay doesn't need it
 *   - Notification channel created for Android 8+
 */
public class ESPOverlayService extends Service {

    private static final String CHANNEL_ID   = "oxide_esp_channel";
    private static final int    NOTIF_ID     = 7777;

    private WindowManager wm;
    private ESPView espView;
    private WindowManager.LayoutParams params;

    @Override
    public void onCreate() {
        super.onCreate();

        // Must call startForeground() within 5 seconds on Android 8+ or ANR/kill
        createNotificationChannel();
        startForeground(NOTIF_ID, buildNotification());

        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        espView = new ESPView(this);

        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                        | WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH
                        | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
                PixelFormat.TRANSLUCENT
        );
        params.gravity = Gravity.TOP | Gravity.START;

        wm.addView(espView, params);
        espView.startUpdating();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID,
                    "OxideESP Overlay",
                    NotificationManager.IMPORTANCE_LOW   // silent, no vibration
            );
            ch.setDescription("ESP overlay is active");
            ch.enableLights(false);
            ch.enableVibration(false);
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(ch);
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(
                this, 0, stopIntent,
                PendingIntent.FLAG_IMMUTABLE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            return new Notification.Builder(this, CHANNEL_ID)
                    .setContentTitle("OxideESP")
                    .setContentText("ESP overlay running — tap to open")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
        } else {
            //noinspection deprecation
            return new Notification.Builder(this)
                    .setContentTitle("OxideESP")
                    .setContentText("ESP overlay running")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentIntent(pi)
                    .setOngoing(true)
                    .build();
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Restart if killed (GBox may kill background services)
        return START_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (espView != null) {
            espView.stopUpdating();
            if (wm != null) wm.removeView(espView);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
