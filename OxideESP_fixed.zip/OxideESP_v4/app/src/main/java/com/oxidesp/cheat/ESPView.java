package com.oxidesp.cheat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Transparent overlay view — draws ESP boxes, health bars, names,
 * and the floating settings menu.
 *
 * Touch handling:
 *   Single tap on ⚙ button  → open/close menu
 *   Drag the ⚙ button       → move it anywhere on screen
 *   Tapping menu toggles     → flip boolean settings
 */
public class ESPView extends View {

    private static final String TAG = "OxideESP_View";
    private static final int UPDATE_MS = 50; // 20 fps for ESP data

    // ------------------------------------------------------------------ //
    //  Settings (toggled from menu)                                        //
    // ------------------------------------------------------------------ //
    boolean espEnabled      = true;
    boolean showNames       = true;
    boolean showHealth      = true;
    boolean showDistance    = true;
    boolean showBox         = true;
    boolean showTeam        = false;
    boolean showSkeleton    = false;  // placeholder – requires bone offsets
    int     maxEspDistance  = 300;   // meters

    // ------------------------------------------------------------------ //
    //  Paints                                                              //
    // ------------------------------------------------------------------ //
    private final Paint paintBox      = new Paint();
    private final Paint paintBoxFill  = new Paint();
    private final Paint paintName     = new Paint();
    private final Paint paintHealth   = new Paint();
    private final Paint paintHealthBg = new Paint();
    private final Paint paintMenu     = new Paint();
    private final Paint paintMenuText = new Paint();
    private final Paint paintMenuSel  = new Paint();
    private final Paint paintGear     = new Paint();
    private final Paint paintLine     = new Paint();

    // ------------------------------------------------------------------ //
    //  State                                                               //
    // ------------------------------------------------------------------ //
    private final Context ctx;
    private GameState gameState;
    private MemReader memReader;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread updateThread;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private int screenW, screenH;

    // Gear button
    private float gearX = 60f, gearY = 200f;
    private boolean menuOpen = false;
    private float dragStartX, dragStartY, dragGearX0, dragGearY0;
    private boolean isDragging = false;
    private static final float GEAR_RADIUS = 38f;
    private static final float DRAG_THRESHOLD = 12f;

    // Menu layout
    private static final float MENU_W = 280f;
    private static final float MENU_ROW = 52f;
    private static final float MENU_PADDING = 16f;

    private final String[] MENU_LABELS = {
            "ESP ON/OFF",
            "Names",
            "Health bar",
            "Distance",
            "Box",
            "Show Team",
            "Max Dist: " + maxEspDistance + "m"
    };

    // ------------------------------------------------------------------ //
    //  Constructor                                                         //
    // ------------------------------------------------------------------ //
    public ESPView(Context context) {
        super(context);
        this.ctx = context;
        setLayerType(LAYER_TYPE_HARDWARE, null);
        initPaints();
        initGame();
    }

    // ------------------------------------------------------------------ //
    //  Paint init                                                          //
    // ------------------------------------------------------------------ //
    private void initPaints() {
        paintBox.setStyle(Paint.Style.STROKE);
        paintBox.setStrokeWidth(2.5f);
        paintBox.setAntiAlias(true);

        paintBoxFill.setStyle(Paint.Style.FILL);
        paintBoxFill.setColor(Color.argb(30, 255, 50, 50));

        paintName.setTextSize(28f);
        paintName.setTypeface(Typeface.DEFAULT_BOLD);
        paintName.setAntiAlias(true);
        paintName.setShadowLayer(4f, 1f, 1f, Color.BLACK);

        paintHealth.setStyle(Paint.Style.FILL);
        paintHealth.setAntiAlias(true);

        paintHealthBg.setStyle(Paint.Style.FILL);
        paintHealthBg.setColor(Color.argb(180, 30, 30, 30));

        paintMenu.setStyle(Paint.Style.FILL);
        paintMenu.setColor(Color.argb(210, 18, 18, 28));
        paintMenu.setAntiAlias(true);

        paintMenuText.setTextSize(30f);
        paintMenuText.setAntiAlias(true);
        paintMenuText.setTypeface(Typeface.MONOSPACE);

        paintMenuSel.setStyle(Paint.Style.FILL);
        paintMenuSel.setColor(Color.argb(90, 60, 180, 255));

        paintGear.setAntiAlias(true);
        paintGear.setStyle(Paint.Style.FILL);

        paintLine.setStyle(Paint.Style.STROKE);
        paintLine.setStrokeWidth(1.5f);
        paintLine.setAntiAlias(true);
    }

    // ------------------------------------------------------------------ //
    //  Game init — find PID and attach memory reader                      //
    // ------------------------------------------------------------------ //
    private void initGame() {
        new Thread(() -> {
            try {
                int pid = findGamePid();
                if (pid == 0) {
                    Log.e(TAG, "Game process not found — waiting…");
                    Thread.sleep(3000);
                    uiHandler.post(this::initGame);
                    return;
                }
                Log.d(TAG, "Oxide PID: " + pid);
                memReader = new MemReader(pid);
                if (!memReader.init()) {
                    Log.e(TAG, "MemReader init failed");
                    return;
                }
                gameState = new GameState(memReader);
                if (!gameState.init(pid)) {
                    Log.e(TAG, "GameState init failed");
                }
            } catch (Exception e) {
                Log.e(TAG, "initGame: " + e.getMessage());
            }
        }, "ESP-Init").start();
    }

    /**
     * Find the PID of com.hyperhug.oxide (Oxide Survival Island package).
     * Reads /proc/*/cmdline.
     */
    private int findGamePid() {
        try {
            java.io.File proc = new java.io.File("/proc");
            for (java.io.File f : proc.listFiles()) {
                if (!f.getName().matches("\\d+")) continue;
                java.io.File cmdline = new java.io.File(f, "cmdline");
                if (!cmdline.exists()) continue;
                try {
                    byte[] buf = new java.io.FileInputStream(cmdline).readAllBytes();
                    String name = new String(buf).split("\0")[0];
                    if (name.contains("oxide") || name.contains("hyperhug")) {
                        return Integer.parseInt(f.getName());
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            Log.e(TAG, "findPid: " + e.getMessage());
        }
        return 0;
    }

    // ------------------------------------------------------------------ //
    //  Update thread                                                       //
    // ------------------------------------------------------------------ //
    public void startUpdating() {
        running.set(true);
        updateThread = new Thread(() -> {
            while (running.get()) {
                try {
                    if (gameState != null) {
                        gameState.update();
                        postInvalidate();
                    }
                    Thread.sleep(UPDATE_MS);
                } catch (InterruptedException e) {
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "update: " + e.getMessage());
                }
            }
        }, "ESP-Update");
        updateThread.setDaemon(true);
        updateThread.start();
    }

    public void stopUpdating() {
        running.set(false);
        if (updateThread != null) updateThread.interrupt();
        if (memReader != null) memReader.close();
    }

    // ------------------------------------------------------------------ //
    //  Drawing                                                             //
    // ------------------------------------------------------------------ //
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        screenW = w; screenH = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (screenW == 0 || screenH == 0) return;

        if (espEnabled && gameState != null) {
            List<GameState.PlayerInfo> snap = gameState.players;
            for (GameState.PlayerInfo p : snap) {
                if (!p.visible) continue;
                if (p.isLocalPlayer) continue;
                if (p.distance > maxEspDistance) continue;
                drawPlayer(canvas, p);
            }
        }

        drawGearButton(canvas);
        if (menuOpen) drawMenu(canvas);
    }

    private void drawPlayer(Canvas canvas, GameState.PlayerInfo p) {
        float sx = p.screenX * screenW;
        float sy = p.screenY * screenH;

        // Estimate box height from distance (rough FOV-based scaling)
        float boxH = Math.max(20f, Math.min(500f, screenH * 1.7f / Math.max(1f, p.distance)));
        float boxW = boxH * 0.4f;

        // Shift sy — our sx/sy is the head position
        float top    = sy;
        float bottom = sy + boxH;
        float left   = sx - boxW / 2f;
        float right  = sx + boxW / 2f;

        // Health color: green → yellow → red
        float hpFrac = Math.min(1f, Math.max(0f, p.health / p.maxHP));
        int r = (int)((1f - hpFrac) * 255);
        int g = (int)(hpFrac * 220);
        int hpColor = Color.rgb(r, g, 40);

        // Box
        if (showBox) {
            paintBox.setColor(hpColor);
            canvas.drawRect(left, top, right, bottom, paintBox);
        }

        // Health bar (left of box)
        if (showHealth) {
            float barX   = left - 10f;
            float barTop = top;
            float barBot = bottom;
            float barH   = barBot - barTop;
            canvas.drawRect(barX - 4f, barTop, barX, barBot, paintHealthBg);
            paintHealth.setColor(hpColor);
            canvas.drawRect(barX - 4f, barTop + barH * (1f - hpFrac), barX, barBot, paintHealth);
        }

        // Name
        if (showNames) {
            String label = p.name.isEmpty() ? "Player" : p.name;
            if (showTeam && !p.team.isEmpty()) label = "[" + p.team + "] " + label;
            paintName.setColor(Color.WHITE);
            canvas.drawText(label, sx - paintName.measureText(label) / 2f, top - 6f, paintName);
        }

        // Distance
        if (showDistance) {
            String dist = Math.round(p.distance) + "m";
            paintName.setColor(Color.argb(200, 255, 220, 80));
            paintName.setTextSize(22f);
            canvas.drawText(dist, sx - paintName.measureText(dist) / 2f, bottom + 22f, paintName);
            paintName.setTextSize(28f);
        }
    }

    // ------------------------------------------------------------------ //
    //  Gear button                                                         //
    // ------------------------------------------------------------------ //
    private void drawGearButton(Canvas canvas) {
        // Background circle
        paintGear.setColor(menuOpen
                ? Color.argb(230, 40, 120, 255)
                : Color.argb(200, 30, 30, 50));
        canvas.drawCircle(gearX, gearY, GEAR_RADIUS, paintGear);
        // Border
        paintGear.setStyle(Paint.Style.STROKE);
        paintGear.setStrokeWidth(2f);
        paintGear.setColor(Color.argb(255, 80, 180, 255));
        canvas.drawCircle(gearX, gearY, GEAR_RADIUS, paintGear);
        paintGear.setStyle(Paint.Style.FILL);
        // ⚙ text
        Paint txt = new Paint();
        txt.setColor(Color.WHITE);
        txt.setTextSize(36f);
        txt.setAntiAlias(true);
        txt.setTextAlign(Paint.Align.CENTER);
        canvas.drawText("⚙", gearX, gearY + 13f, txt);
    }

    // ------------------------------------------------------------------ //
    //  Settings menu                                                       //
    // ------------------------------------------------------------------ //
    private void drawMenu(Canvas canvas) {
        float mx = gearX + GEAR_RADIUS + 10f;
        float my = gearY - GEAR_RADIUS;
        // Clamp to screen
        if (mx + MENU_W > screenW) mx = gearX - GEAR_RADIUS - 10f - MENU_W;
        if (my < 10f) my = 10f;

        int rows = MENU_LABELS.length;
        float mh = MENU_PADDING * 2 + rows * MENU_ROW;

        // Background
        RectF bg = new RectF(mx, my, mx + MENU_W, my + mh);
        canvas.drawRoundRect(bg, 18f, 18f, paintMenu);

        // Title
        paintMenuText.setColor(Color.argb(255, 80, 200, 255));
        paintMenuText.setTextSize(26f);
        canvas.drawText("OxideESP v1.0", mx + MENU_PADDING, my + MENU_PADDING + 22f, paintMenuText);

        // Separator
        paintLine.setColor(Color.argb(120, 80, 180, 255));
        canvas.drawLine(mx + 8f, my + MENU_PADDING + 34f,
                mx + MENU_W - 8f, my + MENU_PADDING + 34f, paintLine);

        paintMenuText.setTextSize(28f);

        boolean[] states = getMenuStates();
        for (int i = 0; i < rows; i++) {
            float rowY = my + MENU_PADDING + 40f + i * MENU_ROW;
            // Hover highlight — skip for now
            // Toggle indicator
            boolean on = (i < states.length) && states[i];
            paintMenuText.setColor(on ? Color.argb(255, 50, 220, 100)
                    : Color.argb(180, 200, 80, 80));
            String indicator = (i < states.length) ? (on ? "✓" : "✗") : "→";
            canvas.drawText(indicator, mx + MENU_PADDING + 4f, rowY + 30f, paintMenuText);

            paintMenuText.setColor(Color.WHITE);
            String label = i == 6
                    ? "Max Dist: " + maxEspDistance + "m"
                    : MENU_LABELS[i];
            canvas.drawText(label, mx + MENU_PADDING + 40f, rowY + 30f, paintMenuText);
        }
    }

    private boolean[] getMenuStates() {
        return new boolean[]{
                espEnabled, showNames, showHealth, showDistance,
                showBox, showTeam,
                true // distance row — always "on" but value changes
        };
    }

    // ------------------------------------------------------------------ //
    //  Touch handling                                                      //
    // ------------------------------------------------------------------ //
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float tx = e.getX(), ty = e.getY();

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                float dg = dist(tx, ty, gearX, gearY);
                if (dg <= GEAR_RADIUS + 10f) {
                    dragStartX = tx; dragStartY = ty;
                    dragGearX0 = gearX; dragGearY0 = gearY;
                    isDragging = false;
                    return true;
                }
                if (menuOpen) {
                    handleMenuTap(tx, ty);
                    return true;
                }
                break;

            case MotionEvent.ACTION_MOVE:
                if (dist(tx, ty, dragStartX, dragStartY) > DRAG_THRESHOLD) {
                    isDragging = true;
                    gearX = dragGearX0 + (tx - dragStartX);
                    gearY = dragGearY0 + (ty - dragStartY);
                    gearX = Math.max(GEAR_RADIUS, Math.min(screenW - GEAR_RADIUS, gearX));
                    gearY = Math.max(GEAR_RADIUS, Math.min(screenH - GEAR_RADIUS, gearY));
                    postInvalidate();
                    return true;
                }
                break;

            case MotionEvent.ACTION_UP:
                if (!isDragging && dist(tx, ty, dragStartX, dragStartY) < DRAG_THRESHOLD) {
                    menuOpen = !menuOpen;
                    postInvalidate();
                }
                isDragging = false;
                return true;
        }
        return false;
    }

    private void handleMenuTap(float tx, float ty) {
        float mx = gearX + GEAR_RADIUS + 10f;
        float my = gearY - GEAR_RADIUS;
        if (mx + MENU_W > screenW) mx = gearX - GEAR_RADIUS - 10f - MENU_W;
        if (my < 10f) my = 10f;

        float contentTop = my + MENU_PADDING + 40f;
        if (tx < mx || tx > mx + MENU_W) { menuOpen = false; postInvalidate(); return; }

        int row = (int)((ty - contentTop) / MENU_ROW);
        if (row < 0 || row >= MENU_LABELS.length) { menuOpen = false; postInvalidate(); return; }

        switch (row) {
            case 0: espEnabled   = !espEnabled;   break;
            case 1: showNames    = !showNames;     break;
            case 2: showHealth   = !showHealth;    break;
            case 3: showDistance = !showDistance;  break;
            case 4: showBox      = !showBox;       break;
            case 5: showTeam     = !showTeam;      break;
            case 6:
                // Cycle max distance: 100 → 200 → 300 → 500 → 100
                if (maxEspDistance < 200)      maxEspDistance = 200;
                else if (maxEspDistance < 300) maxEspDistance = 300;
                else if (maxEspDistance < 500) maxEspDistance = 500;
                else                           maxEspDistance = 100;
                break;
        }
        postInvalidate();
    }

    private float dist(float ax, float ay, float bx, float by) {
        float dx = ax - bx, dy = ay - by;
        return (float) Math.sqrt(dx*dx + dy*dy);
    }
}
