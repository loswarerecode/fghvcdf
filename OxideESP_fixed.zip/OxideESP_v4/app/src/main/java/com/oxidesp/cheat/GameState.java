package com.oxidesp.cheat;

import android.util.Log;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Reads game state from Oxide Survival Island via MemReader.
 *
 * Called every ~50 ms from ESPView's update thread.
 *
 * Static field address resolution:
 *   We read PlayerManager.clientPlayerList (List<PlayerManager>) from the
 *   IL2CPP static fields. The TypeInfo for PlayerManager is exported as
 *   the symbol "PlayerManager_TypeInfo" in libil2cpp.so (or we can scan
 *   /proc/<pid>/maps + symbol table). The static fields block pointer
 *   lives at TypeInfo + 0xB8, and clientPlayerList is the third static
 *   field (index 2, offset 0x10 from static block start).
 *
 *   For simplicity we resolve the address once at startup by iterating
 *   /proc/<pid>/maps and reading the ELF symbol table.
 *   (see resolveStaticList())
 */
public class GameState {

    private static final String TAG = "OxideESP_State";
    private static final long TYPEINFO_STATIC_OFFSET = 0xB8; // staticFields ptr in TypeInfo

    // Il2Cpp RVAs from dump (PlayerManager.clientPlayerList static field)
    // TypeDef index 9223 — we scan the symbol table for PlayerManager_TypeInfo
    private static final String TYPEINFO_SYMBOL = "PlayerManager_TypeInfo";

    public static class PlayerInfo {
        public String name     = "";
        public String team     = "";
        public float  health   = 0f;
        public float  maxHP    = 100f;
        public float  worldX, worldY, worldZ;
        public float  screenX, screenY;
        public boolean visible = false;
        public float  distance = 0f;
        public boolean isLocalPlayer = false;
    }

    private final MemReader mem;
    private long staticListAddr = 0;   // pointer to the List<PlayerManager> object
    private long localPlayerPtr = 0;   // local player instance

    // Camera matrix (VP) — we read Unity Camera matrices via native ptr
    // Camera.projectionMatrix at nativePtr + 0x168 (4x4 row-major floats)
    // Camera.worldToCameraMatrix at nativePtr + 0x1A8
    private float[] vpMatrix = new float[16];

    public final List<PlayerInfo> players = new ArrayList<>();

    public GameState(MemReader mem) {
        this.mem = mem;
    }

    // ------------------------------------------------------------------ //
    //  Init — find static list address once                               //
    // ------------------------------------------------------------------ //

    public boolean init(int pid) {
        staticListAddr = resolveStaticList(pid);
        if (staticListAddr == 0) {
            Log.e(TAG, "Could not resolve clientPlayerList");
            return false;
        }
        Log.d(TAG, String.format("clientPlayerList @ 0x%X", staticListAddr));
        return true;
    }

    /**
     * Scan /proc/<pid>/maps for libil2cpp.so, then parse its ELF symbol table
     * to find PlayerManager_TypeInfo, and from there the static fields block
     * containing clientPlayerList.
     *
     * As a fallback, we do a signature scan for the List<PlayerManager> object.
     */
    private long resolveStaticList(int pid) {
        long il2cppBase = mem.getIl2CppBase();
        if (il2cppBase == 0) return 0;

        // Try ELF symbol scan via nm/readelf if available on device,
        // otherwise fall back to known compiled-in RVA for this build.
        // From dump: PlayerManager TypeDefIndex 9223
        // The TypeInfo RVA can be found via the g_Il2CppTypeDefinitions table.
        // For this build we use the offset resolved from the script.json metadata.
        // script.json lists PlayerManager at index 9223.
        // We use the MonoManager singleton approach:
        //   Read the static field directly using IL2CPP's global metadata.
        //
        // Practical approach: scan maps for "bss" segment of libil2cpp.so
        // and do a pattern/signature scan for a valid List<PlayerManager> object.
        // For now we use the known compiled offset from this build's dump.
        //
        // RVA of PlayerManager$$get_clientPlayerList = 0x636E2F8
        // This function does: ldp x8, x9, [x0, #0xB8]; ... ldr x0, [x8, #0x10]
        // Meaning: TypeInfo+0xB8 → staticFields; staticFields+0x10 → clientPlayerList
        //
        // We find TypeInfo by resolving the symbol in the ELF .dynsym:

        long typeInfoAddr = resolveSymbol(pid, "PlayerManager_TypeInfo");
        if (typeInfoAddr == 0) {
            Log.w(TAG, "Symbol not found, trying compiled RVA approach");
            // last resort: hardcoded from the function body
            // get_clientPlayerList RVA = 0x636E2F8 → reads from a PC-relative adrp
            // we compute the TypeInfo address from the instruction encoding
            typeInfoAddr = resolveTypeInfoFromCode(il2cppBase, 0x636E2F8L);
        }
        if (typeInfoAddr == 0) return 0;

        long staticFieldsPtr = mem.readLong(typeInfoAddr + TYPEINFO_STATIC_OFFSET);
        if (staticFieldsPtr == 0) return 0;

        // clientPlayerList is at static offset 0x10 (third field: serverName 0x18, serverBuildNumber 0x20 are after it per dump)
        // Wait — from dump: static fields are:
        //   sleepingPlayerList  → 0x0
        //   activePlayerList    → 0x8
        //   clientPlayerList    → 0x10   ← this is the pointer to the List object
        //   serverName          → 0x18
        //   serverBuildNumber   → 0x20
        long listObjPtr = mem.readLong(staticFieldsPtr + 0x10);
        return listObjPtr;
    }

    /**
     * Parse /proc/<pid>/maps + ELF symbol table to find a symbol address.
     * Uses /proc/<pid>/fd + readelf/nm if available, or manual ELF parsing.
     */
    private long resolveSymbol(int pid, String symbolName) {
        try {
            // Find the path of libil2cpp.so from maps
            String libPath = null;
            BufferedReader maps = new BufferedReader(
                new InputStreamReader(
                    new java.io.FileInputStream("/proc/" + pid + "/maps")));
            String line;
            while ((line = maps.readLine()) != null) {
                if (line.contains("libil2cpp.so") && line.contains("r-xp")) {
                    // Extract path — last field after whitespace
                    String[] parts = line.trim().split("\\s+");
                    if (parts.length >= 6) {
                        libPath = parts[5];
                        break;
                    }
                }
            }
            maps.close();
            if (libPath == null) return 0;

            // Run "nm -D" or parse ELF manually
            // ELF manual parse:
            return parseElfSymbol(libPath, symbolName, mem.getIl2CppBase());
        } catch (Exception e) {
            Log.e(TAG, "resolveSymbol: " + e.getMessage());
            return 0;
        }
    }

    /**
     * Minimal ELF64 symbol table parser — reads .dynsym to find a symbol.
     * Returns virtual address (file VA + slide).
     */
    private long parseElfSymbol(String libPath, String symName, long base) {
        try (java.io.RandomAccessFile elf = new java.io.RandomAccessFile(libPath, "r")) {
            // ELF header: e_shoff @ 0x28, e_shentsize @ 0x3A, e_shnum @ 0x3C, e_shstrndx @ 0x3E
            byte[] hdr = new byte[64];
            elf.read(hdr);
            java.nio.ByteBuffer h = java.nio.ByteBuffer.wrap(hdr)
                    .order(java.nio.ByteOrder.LITTLE_ENDIAN);
            if (h.get(0) != 0x7F || h.get(1) != 'E') return 0; // not ELF

            long  shoff    = h.getLong(0x28);
            short shentsz  = h.getShort(0x3A);
            short shnum    = h.getShort(0x3C);
            short shstrndx = h.getShort(0x3E);

            // Read section headers
            long dynSymOff = 0, dynSymSz = 0;
            long dynStrOff = 0, dynStrSz = 0;

            for (int i = 0; i < shnum; i++) {
                elf.seek(shoff + (long) i * shentsz);
                byte[] shbuf = new byte[64];
                elf.read(shbuf);
                java.nio.ByteBuffer sh = java.nio.ByteBuffer.wrap(shbuf)
                        .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int  sh_type = sh.getInt(0x04);
                long sh_off  = sh.getLong(0x18);
                long sh_sz   = sh.getLong(0x20);
                long sh_link = sh.getInt(0x28) & 0xFFFFFFFFL;

                if (sh_type == 11 /* SHT_DYNSYM */) {
                    dynSymOff = sh_off;
                    dynSymSz  = sh_sz;
                    // Linked section is strtab
                    elf.seek(shoff + sh_link * shentsz + 0x18);
                    byte[] strbuf = new byte[16];
                    elf.read(strbuf);
                    java.nio.ByteBuffer strsh = java.nio.ByteBuffer.wrap(strbuf)
                            .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                    dynStrOff = strsh.getLong(0);
                    dynStrSz  = strsh.getLong(8);
                }
            }
            if (dynSymOff == 0) return 0;

            // Read string table
            elf.seek(dynStrOff);
            byte[] strTable = new byte[(int) dynStrSz];
            elf.read(strTable);

            // Iterate symbols (Elf64_Sym = 24 bytes)
            long symCount = dynSymSz / 24;
            for (long i = 0; i < symCount; i++) {
                elf.seek(dynSymOff + i * 24);
                byte[] sym = new byte[24];
                elf.read(sym);
                java.nio.ByteBuffer s = java.nio.ByteBuffer.wrap(sym)
                        .order(java.nio.ByteOrder.LITTLE_ENDIAN);
                int  nameOff = s.getInt(0);
                long value   = s.getLong(8);
                if (value == 0) continue;

                // Read symbol name from string table
                StringBuilder sb = new StringBuilder();
                for (int j = nameOff; j < strTable.length && strTable[j] != 0; j++) {
                    sb.append((char) strTable[j]);
                }
                if (sb.toString().equals(symName)) {
                    // value is the file-relative VA; add ASLR slide
                    // slide = base − (first load segment VA in file)
                    // For Android PIE: base is already the in-memory address of 0x0 in file
                    return base + value;
                }
            }
        } catch (Exception e) {
            Log.e(TAG, "ELF parse: " + e.getMessage());
        }
        return 0;
    }

    /**
     * Fallback: decode ARM64 ADRP+LDR sequence at the start of
     * PlayerManager$$get_clientPlayerList to find the TypeInfo address.
     * RVA = 0x636E2F8 in this build.
     */
    private long resolveTypeInfoFromCode(long il2cppBase, long funcRva) {
        long funcVa = il2cppBase + funcRva;
        // First instruction is typically:  adrp x8, #pageOffset
        // Instruction: 0x--000090 (ADRP)
        int instr = mem.readInt(funcVa);
        if ((instr & 0x9F000000) != 0x90000000) return 0;
        // Decode ADRP: immhi:immlo, target page = PC-aligned + (imm << 12)
        long immlo = (instr >> 29) & 0x3;
        long immhi = (instr >> 5)  & 0x7FFFF;
        long imm   = (immhi << 2 | immlo);
        // Sign-extend from 21 bits
        if ((imm & (1L << 20)) != 0) imm |= ~((1L << 21) - 1);
        long page   = (funcVa & ~0xFFFL) + (imm << 12);
        // Second instruction: LDR x8, [x8, #offset]  (0xF9400000 form)
        int ldr = mem.readInt(funcVa + 4);
        long ldrOffset = ((ldr >> 10) & 0xFFF) * 8L; // unsigned, scaled by 8
        return page + ldrOffset;
    }

    // ------------------------------------------------------------------ //
    //  Per-frame update                                                    //
    // ------------------------------------------------------------------ //

    public void update() {
        players.clear();
        if (staticListAddr == 0) return;

        // Re-read the list object pointer each frame (GC may move it)
        // clientPlayerList is a static readonly so it won't change often,
        // but let's re-read from staticFields for safety
        // (already stored in staticListAddr)

        int count = mem.readListSize(staticListAddr);
        if (count <= 0 || count > 200) return;

        // Read camera VP matrix from the local player's FPManager camera
        updateCameraMatrix();

        for (int i = 0; i < count; i++) {
            long pmPtr = mem.readListElement(staticListAddr, i);
            if (pmPtr == 0) continue;

            PlayerInfo p = new PlayerInfo();
            readPlayerInfo(pmPtr, p);

            // World-to-screen projection
            projectToScreen(p);

            players.add(p);
        }
    }

    private void readPlayerInfo(long pmPtr, PlayerInfo p) {
        // name: nicklabel.character... but easiest: userID string
        // Real display name is in LWQ (protected string at 0x220)
        long namePtr = mem.readLong(pmPtr + 0x220); // LWQ (protected string displayName)
        if (namePtr != 0) p.name = mem.readString(namePtr);
        if (p.name.isEmpty()) {
            long uidPtr = mem.readLong(pmPtr + MemReader.OFF_PM_USERID);
            if (uidPtr != 0) p.name = mem.readString(uidPtr);
        }

        long teamPtr = mem.readLong(pmPtr + MemReader.OFF_PM_TEAMNAME);
        if (teamPtr != 0) p.team = mem.readString(teamPtr);

        // Health from vitals (PlayerVitals → GenericVitals → Ljs @ 0xB8, m_MaxHealth @ 0x88)
        long vitalsPtr = mem.readLong(pmPtr + MemReader.OFF_PM_VITALS);
        if (vitalsPtr != 0) {
            p.health  = mem.readFloat(vitalsPtr + MemReader.OFF_VITALS_CUR_HEALTH);
            p.maxHP   = mem.readFloat(vitalsPtr + MemReader.OFF_VITALS_MAX_HEALTH);
            if (p.maxHP <= 0) p.maxHP = 100f;
        }

        // World position via nicklabel.character Transform
        long nicklabelPtr = mem.readLong(pmPtr + MemReader.OFF_PM_NICKLABEL);
        if (nicklabelPtr != 0) {
            long charTransform = mem.readLong(nicklabelPtr + MemReader.OFF_NICKLABEL_CHAR);
            float[] pos = mem.readTransformPosition(charTransform);
            p.worldX = pos[0]; p.worldY = pos[1]; p.worldZ = pos[2];
        }
    }

    // ------------------------------------------------------------------ //
    //  Camera / projection                                                 //
    // ------------------------------------------------------------------ //

    private long cameraPtr = 0;

    private void updateCameraMatrix() {
        // Find Camera from local player's FPManager
        if (cameraPtr == 0) {
            long lp = findLocalPlayer();
            if (lp == 0) return;
            long fpm = mem.readLong(lp + MemReader.OFF_PM_FPMANAGER);
            if (fpm == 0) return;
            long camManaged = mem.readLong(fpm + MemReader.OFF_FPM_WORLD_CAM);
            if (camManaged == 0) return;
            cameraPtr = mem.readLong(camManaged + MemReader.OFF_MONOBEHAVIOUR_PTR);
        }
        if (cameraPtr == 0) return;

        // Unity Camera native layout (Unity 2021 LTS, ARM64):
        //   +0x168 : projectionMatrix (float[16], row-major)
        //   +0x1A8 : worldToCameraMatrix (float[16])
        // We need VP = P * V
        float[] proj = new float[16];
        float[] view = new float[16];
        for (int i = 0; i < 16; i++) {
            proj[i] = mem.readFloat(cameraPtr + 0x168 + i * 4);
            view[i] = mem.readFloat(cameraPtr + 0x1A8 + i * 4);
        }
        vpMatrix = multiply4x4(proj, view);
    }

    private long findLocalPlayer() {
        // Local player is the first entry in clientPlayerList whose
        // networkPositionObserver / isLocalPlayer flag is set.
        // Simplest check: fpManager.m_WorldCamera != null
        int count = mem.readListSize(staticListAddr);
        for (int i = 0; i < Math.min(count, 200); i++) {
            long pmPtr = mem.readListElement(staticListAddr, i);
            if (pmPtr == 0) continue;
            long fpm = mem.readLong(pmPtr + MemReader.OFF_PM_FPMANAGER);
            if (fpm == 0) continue;
            long cam = mem.readLong(fpm + MemReader.OFF_FPM_WORLD_CAM);
            if (cam != 0) { localPlayerPtr = pmPtr; return pmPtr; }
        }
        return 0;
    }

    private void projectToScreen(PlayerInfo p) {
        // Head position (y+1.7 above feet)
        float wx = p.worldX, wy = p.worldY + 1.7f, wz = p.worldZ;

        // Clip coords: multiply by VP (row-major)
        float cx = vpMatrix[0]*wx + vpMatrix[1]*wy + vpMatrix[2]*wz  + vpMatrix[3];
        float cy = vpMatrix[4]*wx + vpMatrix[5]*wy + vpMatrix[6]*wz  + vpMatrix[7];
        float cz = vpMatrix[8]*wx + vpMatrix[9]*wy + vpMatrix[10]*wz + vpMatrix[11];
        float cw = vpMatrix[12]*wx+ vpMatrix[13]*wy+ vpMatrix[14]*wz + vpMatrix[15];

        if (cw <= 0.01f) { p.visible = false; return; }

        // NDC
        float ndcX =  cx / cw;
        float ndcY = -cy / cw;  // flip Y (OpenGL → screen)

        // Screen (set by ESPView once we know display size)
        p.screenX = (ndcX + 1f) * 0.5f;  // 0..1
        p.screenY = (ndcY + 1f) * 0.5f;
        p.visible  = (p.screenX >= 0f && p.screenX <= 1f &&
                      p.screenY >= 0f && p.screenY <= 1f);

        // Feet distance from camera
        p.distance = (float) Math.sqrt(
                (p.worldX - getLocalX()) * (p.worldX - getLocalX()) +
                (p.worldZ - getLocalZ()) * (p.worldZ - getLocalZ()));
    }

    // Cache local position
    private float lx, lz;
    private float getLocalX() { return lx; }
    private float getLocalZ() { return lz; }

    private static float[] multiply4x4(float[] a, float[] b) {
        float[] r = new float[16];
        for (int row = 0; row < 4; row++)
            for (int col = 0; col < 4; col++)
                for (int k = 0; k < 4; k++)
                    r[row*4+col] += a[row*4+k] * b[k*4+col];
        return r;
    }
}
