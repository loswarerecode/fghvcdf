# Keep all ESP classes intact — /proc parsing and reflection must work
-keep class com.oxidesp.cheat.** { *; }

# Keep RandomAccessFile and FileInputStream used for /proc/mem reading
-keepclassmembers class java.io.RandomAccessFile { *; }
-keepclassmembers class java.io.FileInputStream { *; }

# Keep ByteBuffer used for little-endian memory reads
-keepclassmembers class java.nio.ByteBuffer { *; }

# Suppress warnings about missing Android classes
-dontwarn android.**
-dontwarn androidx.**
