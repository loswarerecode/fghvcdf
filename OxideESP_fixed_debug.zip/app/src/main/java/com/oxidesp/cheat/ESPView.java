package com.oxidesp.cheat;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.MotionEvent;
import android.view.WindowManager;
import android.view.View;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class ESPView extends View {

    private static final String TAG       = "OxideESP_View";
    private static final int    UPDATE_MS = 50;

    // ── Settings ───────────────────────────────────────────────────────
    boolean espEnabled     = true;
    boolean showNames      = true;
    boolean showHealth     = true;
    boolean showDistance   = true;
    boolean showBox        = true;
    boolean showTeam       = false;
    boolean showSkeleton   = false;
    boolean showLines      = false;
    int     maxEspDistance = 300;

    // ── State ──────────────────────────────────────────────────────────
    private final Context ctx;
    private WindowManager wm;
    private WindowManager.LayoutParams overlayParams;
    GameState    gameState;
    private MemReader    memReader;
    private DebugInfo    debugInfo;
    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread updateThread;
    private final Handler uiHandler = new Handler(Looper.getMainLooper());

    private int screenW, screenH;

    // ── Gear / Menu ────────────────────────────────────────────────────
    float   gearX = 60f, gearY = 200f;
    boolean menuOpen      = false;
    boolean debugMenuOpen = false;   // ← второе меню

    private static final float GEAR_RADIUS    = 38f;
    private static final float MENU_W         = 300f;
    private static final float MENU_ROW       = 52f;
    private static final float MENU_PADDING   = 16f;

    // ── Menus ──────────────────────────────────────────────────────────
    private static final String[] MENU_LABELS = {
            "ESP ON/OFF", "Box", "Skeleton", "Lines",
            "Names", "Health bar", "Distance", "Max Dist"
    };

    // ── Paints ─────────────────────────────────────────────────────────
    private final Paint pBox      = new Paint();
    private final Paint pBoxFill  = new Paint();
    private final Paint pName     = new Paint();
    private final Paint pHealth   = new Paint();
    private final Paint pHealthBg = new Paint();
    private final Paint pMenu     = new Paint();
    private final Paint pMenuHdr  = new Paint();
    private final Paint pMenuTxt  = new Paint();
    private final Paint pLine     = new Paint();
    private final Paint pDivider  = new Paint();
    private final Paint pDbgOk    = new Paint();
    private final Paint pDbgFail  = new Paint();
    private final Paint pDbgWarn  = new Paint();
    private final Paint pDbgGray  = new Paint();
    private final Paint pDbgVal   = new Paint();
    private final Paint pStatusBg = new Paint();

    // ── Constructor ────────────────────────────────────────────────────
    public ESPView(Context context) {
        super(context);
        this.ctx = context;
        setLayerType(LAYER_TYPE_HARDWARE, null);
        initPaints();
        debugInfo = new DebugInfo();
        initGame();
    }

    public void setWindowManager(WindowManager wm, WindowManager.LayoutParams params) {
        this.wm = wm;
        this.overlayParams = params;
    }

    void enableTouch(boolean enable) {
        if (wm == null || overlayParams == null) return;
        if (enable) overlayParams.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else        overlayParams.flags |=  WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        try { wm.updateViewLayout(this, overlayParams); } catch (Exception ignored) {}
    }

    // ── Paints init ────────────────────────────────────────────────────
    private void initPaints() {
        pBox.setStyle(Paint.Style.STROKE);
        pBox.setStrokeWidth(2.5f);
        pBox.setAntiAlias(true);

        pBoxFill.setStyle(Paint.Style.FILL);
        pBoxFill.setColor(Color.argb(30, 255, 50, 50));

        pName.setTextSize(28f);
        pName.setTypeface(Typeface.DEFAULT_BOLD);
        pName.setAntiAlias(true);
        pName.setShadowLayer(4f, 1f, 1f, Color.BLACK);

        pHealth.setStyle(Paint.Style.FILL);
        pHealth.setAntiAlias(true);

        pHealthBg.setStyle(Paint.Style.FILL);
        pHealthBg.setColor(Color.argb(180, 30, 30, 30));

        // Меню фон — тёмный с лёгким синим оттенком
        pMenu.setStyle(Paint.Style.FILL);
        pMenu.setColor(Color.argb(225, 12, 14, 26));
        pMenu.setAntiAlias(true);

        pMenuHdr.setTextSize(24f);
        pMenuHdr.setTypeface(Typeface.MONOSPACE);
        pMenuHdr.setAntiAlias(true);
        pMenuHdr.setFakeBoldText(true);

        pMenuTxt.setTextSize(27f);
        pMenuTxt.setAntiAlias(true);
        pMenuTxt.setTypeface(Typeface.MONOSPACE);

        pLine.setStyle(Paint.Style.STROKE);
        pLine.setStrokeWidth(1.5f);
        pLine.setAntiAlias(true);

        pDivider.setStyle(Paint.Style.STROKE);
        pDivider.setStrokeWidth(1f);
        pDivider.setColor(Color.argb(80, 80, 160, 255));
        pDivider.setAntiAlias(true);

        // Debug-цвета
        pDbgOk.setTextSize(22f);   pDbgOk.setAntiAlias(true);   pDbgOk.setTypeface(Typeface.MONOSPACE);
        pDbgOk.setColor(Color.argb(255, 50, 220, 90));

        pDbgFail.setTextSize(22f); pDbgFail.setAntiAlias(true); pDbgFail.setTypeface(Typeface.MONOSPACE);
        pDbgFail.setColor(Color.argb(255, 255, 60, 60));

        pDbgWarn.setTextSize(22f); pDbgWarn.setAntiAlias(true); pDbgWarn.setTypeface(Typeface.MONOSPACE);
        pDbgWarn.setColor(Color.argb(255, 255, 190, 40));

        pDbgGray.setTextSize(22f); pDbgGray.setAntiAlias(true); pDbgGray.setTypeface(Typeface.MONOSPACE);
        pDbgGray.setColor(Color.argb(160, 180, 180, 180));

        pDbgVal.setTextSize(20f);  pDbgVal.setAntiAlias(true);  pDbgVal.setTypeface(Typeface.MONOSPACE);
        pDbgVal.setColor(Color.argb(200, 140, 200, 255));

        pStatusBg.setStyle(Paint.Style.FILL);
        pStatusBg.setAntiAlias(true);
    }

    // ── Game init ──────────────────────────────────────────────────────
    void initGame() {
        new Thread(() -> {
            try {
                int pid = findGamePid();
                if (pid == 0) {
                    debugInfo.stepPid.warn("not found — retry…");
                    postInvalidate();
                    Thread.sleep(3000);
                    uiHandler.post(this::initGame);
                    return;
                }
                debugInfo.stepPid.ok(String.valueOf(pid));
                postInvalidate();

                if (memReader != null) { memReader.close(); memReader = null; }

                memReader = new MemReader(pid);
                if (!memReader.init(debugInfo)) {
                    postInvalidate();
                    Thread.sleep(5000);
                    uiHandler.post(this::initGame);
                    return;
                }
                postInvalidate();

                gameState = new GameState(memReader);
                if (!gameState.init(pid, debugInfo)) {
                    postInvalidate();
                    Thread.sleep(5000);
                    uiHandler.post(this::initGame);
                    return;
                }
                postInvalidate();

                if (!running.get()) startUpdating();

            } catch (Exception e) {
                Log.e(TAG, "initGame: " + e.getMessage());
            }
        }, "ESP-Init").start();
    }

    private int findGamePid() {
        try {
            java.io.File proc = new java.io.File("/proc");
            java.io.File[] files = proc.listFiles();
            if (files == null) return 0;
            for (java.io.File f : files) {
                if (!f.getName().matches("\\d+")) continue;
                java.io.File cmdline = new java.io.File(f, "cmdline");
                if (!cmdline.exists()) continue;
                try {
                    byte[] buf = new java.io.FileInputStream(cmdline).readAllBytes();
                    String name = new String(buf).split("\0")[0];
                    if (name.contains("oxide") || name.contains("hyperhug")) {
                        return Integer.parseInt(f.getName());
                    }
                } catch (Exception ignored) {}
            }
        } catch (Exception e) {
            Log.e(TAG, "findPid: " + e.getMessage());
        }
        return 0;
    }

    // ── Update thread ──────────────────────────────────────────────────
    public void startUpdating() {
        if (running.getAndSet(true)) return;
        updateThread = new Thread(() -> {
            while (running.get()) {
                try {
                    if (gameState != null) {
                        gameState.update();
                        postInvalidate();
                    }
                    Thread.sleep(UPDATE_MS);
                } catch (InterruptedException e) {
                    break;
                } catch (Exception e) {
                    Log.e(TAG, "update: " + e.getMessage());
                }
            }
        }, "ESP-Update");
        updateThread.setDaemon(true);
        updateThread.start();
    }

    public void stopUpdating() {
        running.set(false);
        if (updateThread != null) updateThread.interrupt();
        if (memReader != null) memReader.close();
    }

    // ── Draw ───────────────────────────────────────────────────────────
    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        screenW = w; screenH = h;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (screenW == 0 || screenH == 0) return;

        if (espEnabled && gameState != null) {
            List<GameState.PlayerInfo> snap = new java.util.ArrayList<>(gameState.players);
            for (GameState.PlayerInfo p : snap) {
                if (!p.visible)                  continue;
                if (p.isLocalPlayer)             continue;
                if (p.distance > maxEspDistance) continue;
                drawPlayer(canvas, p);
            }
        }

        if (menuOpen)      drawSettingsMenu(canvas);
        if (debugMenuOpen) drawDebugMenu(canvas);
    }

    // ── ESP drawing ────────────────────────────────────────────────────
    private void drawPlayer(Canvas canvas, GameState.PlayerInfo p) {
        float sx = p.screenX * screenW;
        float sy = p.screenY * screenH;

        float boxH = Math.max(20f, Math.min(600f, screenH * 1.8f / Math.max(1f, p.distance)));
        float boxW = boxH * 0.4f;

        float top    = sy;
        float bottom = sy + boxH;
        float left   = sx - boxW / 2f;
        float right  = sx + boxW / 2f;

        float hpFrac = Math.min(1f, Math.max(0f, p.health / p.maxHP));
        int   r      = (int)((1f - hpFrac) * 255);
        int   g      = (int)(hpFrac * 220);
        int   hpColor = Color.rgb(r, g, 40);

        if (showBox) {
            pBox.setColor(hpColor);
            canvas.drawRect(left, top, right, bottom, pBox);
        }

        if (showHealth) {
            float barX = left - 8f;
            float barH = bottom - top;
            canvas.drawRect(barX - 4f, top, barX, bottom, pHealthBg);
            pHealth.setColor(hpColor);
            canvas.drawRect(barX - 4f, top + barH * (1f - hpFrac), barX, bottom, pHealth);
        }

        if (showNames) {
            String label = p.name.isEmpty() ? "Player" : p.name;
            if (showTeam && !p.team.isEmpty()) label = "[" + p.team + "] " + label;
            pName.setColor(Color.WHITE);
            pName.setTextSize(28f);
            canvas.drawText(label, sx - pName.measureText(label) / 2f, top - 6f, pName);
        }

        if (showLines) {
            pLine.setColor(Color.argb(180, 255, 80, 80));
            canvas.drawLine(screenW / 2f, screenH, sx, bottom, pLine);
        }

        if (showSkeleton) {
            pLine.setColor(Color.argb(200, 80, 255, 200));
            float midY  = top + boxH * 0.25f;
            float waist = top + boxH * 0.5f;
            float knee  = top + boxH * 0.75f;
            canvas.drawLine(sx, top, sx, bottom, pLine);
            canvas.drawLine(left + boxW*0.1f, midY, right - boxW*0.1f, midY, pLine);
            canvas.drawLine(left + boxW*0.1f, midY, left,  waist, pLine);
            canvas.drawLine(right- boxW*0.1f, midY, right, waist, pLine);
            canvas.drawLine(left + boxW*0.2f, waist, right - boxW*0.2f, waist, pLine);
            canvas.drawLine(left + boxW*0.2f, waist, left + boxW*0.1f, knee,  pLine);
            canvas.drawLine(right- boxW*0.2f, waist, right- boxW*0.1f, knee,  pLine);
            canvas.drawLine(left + boxW*0.1f, knee, left + boxW*0.15f, bottom, pLine);
            canvas.drawLine(right- boxW*0.1f, knee, right- boxW*0.15f, bottom, pLine);
        }

        if (showDistance) {
            String dist = Math.round(p.distance) + "m";
            pName.setColor(Color.argb(200, 255, 220, 80));
            pName.setTextSize(22f);
            canvas.drawText(dist, sx - pName.measureText(dist) / 2f, bottom + 22f, pName);
        }
    }

    // ── Settings menu ──────────────────────────────────────────────────
    private void drawSettingsMenu(Canvas canvas) {
        float[] pos = menuPosition(MENU_W, MENU_PADDING * 2 + MENU_LABELS.length * MENU_ROW + 50f);
        float mx = pos[0], my = pos[1];
        float mh = MENU_PADDING * 2 + MENU_LABELS.length * MENU_ROW + 50f;

        // Фон
        RectF bg = new RectF(mx, my, mx + MENU_W, my + mh);
        canvas.drawRoundRect(bg, 20f, 20f, pMenu);

        // Акцентная полоса сверху
        Paint accent = new Paint(pMenu);
        accent.setColor(Color.argb(255, 50, 120, 255));
        accent.setStyle(Paint.Style.STROKE);
        accent.setStrokeWidth(2.5f);
        canvas.drawRoundRect(bg, 20f, 20f, accent);

        // Заголовок
        pMenuHdr.setColor(Color.argb(255, 90, 190, 255));
        canvas.drawText("⚙  OxideESP v1.0", mx + MENU_PADDING, my + MENU_PADDING + 26f, pMenuHdr);

        // Разделитель
        float divY = my + MENU_PADDING + 38f;
        canvas.drawLine(mx + 12f, divY, mx + MENU_W - 12f, divY, pDivider);

        // Строки
        boolean[] states = getMenuStates();
        for (int i = 0; i < MENU_LABELS.length; i++) {
            float rowY = divY + 10f + i * MENU_ROW;
            boolean on = (i < states.length) && states[i];

            // Highlight активной строки
            if (on && i == 0) {
                RectF hi = new RectF(mx + 6f, rowY + 4f, mx + MENU_W - 6f, rowY + MENU_ROW - 4f);
                Paint hiP = new Paint();
                hiP.setColor(Color.argb(35, 50, 200, 100));
                hiP.setStyle(Paint.Style.FILL);
                canvas.drawRoundRect(hi, 8f, 8f, hiP);
            }

            pMenuTxt.setColor(on ? Color.argb(255, 50, 220, 100)
                                 : Color.argb(180, 200, 80, 80));
            canvas.drawText(on ? "●" : "○", mx + MENU_PADDING + 4f, rowY + 32f, pMenuTxt);

            pMenuTxt.setColor(Color.argb(220, 220, 220, 230));
            String lbl = (i == 7) ? "Max Dist: " + maxEspDistance + "m" : MENU_LABELS[i];
            canvas.drawText(lbl, mx + MENU_PADDING + 36f, rowY + 32f, pMenuTxt);
        }
    }

    // ── Debug menu ─────────────────────────────────────────────────────
    private void drawDebugMenu(Canvas canvas) {
        if (debugInfo == null) return;

        float DBG_W   = Math.min(screenW - 20f, 500f);
        float ROW_H   = 52f;
        List<DebugInfo.Step> steps = debugInfo.initSteps();
        // Секции: init pipeline + runtime stats
        float DBG_H = MENU_PADDING * 2
                    + 34f   // заголовок
                    + 10f   // divider gap
                    + steps.size() * ROW_H
                    + 14f   // divider
                    + 4 * 38f   // runtime rows
                    + 10f;

        // Позиционируем справа от шестерни или в центре если мало места
        float mx, my;
        float gearRight = gearX + GEAR_RADIUS + 14f;
        if (gearRight + DBG_W < screenW - 8f) {
            mx = gearRight;
        } else {
            mx = Math.max(8f, gearX - GEAR_RADIUS - 14f - DBG_W);
        }
        my = Math.max(8f, Math.min(gearY - GEAR_RADIUS, screenH - DBG_H - 8f));

        // Фон
        RectF bg = new RectF(mx, my, mx + DBG_W, my + DBG_H);
        canvas.drawRoundRect(bg, 20f, 20f, pMenu);

        // Рамка (оранжевая если не init, синяя если ок)
        Paint border = new Paint();
        border.setStyle(Paint.Style.STROKE);
        border.setStrokeWidth(2.5f);
        border.setAntiAlias(true);
        border.setColor(debugInfo.isFullyInit()
                ? Color.argb(255, 50, 120, 255)
                : Color.argb(255, 255, 140, 30));
        canvas.drawRoundRect(bg, 20f, 20f, border);

        float y = my + MENU_PADDING;

        // Заголовок
        pMenuHdr.setColor(Color.argb(255, 255, 170, 40));
        canvas.drawText("🔍  Memory Debug", mx + MENU_PADDING, y + 26f, pMenuHdr);
        y += 36f;

        // Divider
        canvas.drawLine(mx + 12f, y, mx + DBG_W - 12f, y, pDivider);
        y += 12f;

        // Init pipeline
        for (DebugInfo.Step step : steps) {
            Paint labelPaint = statusPaint(step.status);
            String icon = statusIcon(step.status);

            // Иконка + метка
            canvas.drawText(icon, mx + MENU_PADDING, y + 24f, labelPaint);
            pDbgGray.setTextSize(21f);
            canvas.drawText(step.label, mx + MENU_PADDING + 28f, y + 24f, pDbgGray);

            // Значение справа (обрезаем если длинное)
            String val = step.value;
            if (val.length() > 22) val = val.substring(0, 20) + "…";
            pDbgVal.setTextSize(19f);
            float vw = pDbgVal.measureText(val);
            canvas.drawText(val, mx + DBG_W - MENU_PADDING - vw, y + 24f, pDbgVal);

            y += ROW_H;
        }

        // Divider runtime
        canvas.drawLine(mx + 12f, y, mx + DBG_W - 12f, y, pDivider);
        y += 12f;

        // Runtime stats
        drawRuntimeRow(canvas, mx, y, DBG_W, "Players",
                String.valueOf(debugInfo.playerCount)); y += 38f;
        drawRuntimeRow(canvas, mx, y, DBG_W, "Visible",
                String.valueOf(debugInfo.visibleCount)); y += 38f;
        drawRuntimeRow(canvas, mx, y, DBG_W, "Camera",
                debugInfo.camStatus.length() > 18
                        ? debugInfo.camStatus.substring(0, 16) + "…"
                        : debugInfo.camStatus); y += 38f;
        drawRuntimeRow(canvas, mx, y, DBG_W, "Update",
                debugInfo.updateHz + " fps"); y += 38f;
    }

    private void drawRuntimeRow(Canvas canvas, float mx, float y, float w,
                                String label, String val) {
        pDbgGray.setTextSize(21f);
        canvas.drawText(label, mx + MENU_PADDING + 28f, y + 20f, pDbgGray);
        pDbgVal.setTextSize(19f);
        float vw = pDbgVal.measureText(val);
        canvas.drawText(val, mx + w - MENU_PADDING - vw, y + 20f, pDbgVal);
    }

    private Paint statusPaint(DebugInfo.Status s) {
        switch (s) {
            case OK:      return pDbgOk;
            case FAIL:    return pDbgFail;
            case WARN:    return pDbgWarn;
            default:      return pDbgGray;
        }
    }

    private String statusIcon(DebugInfo.Status s) {
        switch (s) {
            case OK:   return "✓";
            case FAIL: return "✗";
            case WARN: return "~";
            default:   return "…";
        }
    }

    private float[] menuPosition(float w, float h) {
        float mx = gearX + GEAR_RADIUS + 10f;
        float my = gearY - GEAR_RADIUS;
        if (mx + w > screenW - 8f) mx = gearX - GEAR_RADIUS - 10f - w;
        if (mx < 8f) mx = 8f;
        if (my < 8f) my = 8f;
        if (my + h > screenH - 8f) my = screenH - h - 8f;
        return new float[]{mx, my};
    }

    private boolean[] getMenuStates() {
        return new boolean[]{
                espEnabled, showBox, showSkeleton, showLines,
                showNames, showHealth, showDistance, true
        };
    }

    // ── Touch ──────────────────────────────────────────────────────────
    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (!menuOpen && !debugMenuOpen) return false;
        if (e.getActionMasked() == MotionEvent.ACTION_DOWN) {
            if (menuOpen)      handleSettingsTap(e.getX(), e.getY());
            if (debugMenuOpen) handleDebugTap(e.getX(), e.getY());
            return true;
        }
        return false;
    }

    private void handleSettingsTap(float tx, float ty) {
        float mh = MENU_PADDING * 2 + MENU_LABELS.length * MENU_ROW + 50f;
        float[] pos = menuPosition(MENU_W, mh);
        float mx = pos[0], my = pos[1];

        float divY = my + MENU_PADDING + 38f;
        float contentTop = divY + 10f;

        if (tx < mx || tx > mx + MENU_W) {
            menuOpen = false; enableTouch(false); postInvalidate(); return;
        }
        int row = (int)((ty - contentTop) / MENU_ROW);
        if (row < 0 || row >= MENU_LABELS.length) {
            menuOpen = false; enableTouch(false); postInvalidate(); return;
        }
        switch (row) {
            case 0: espEnabled   = !espEnabled;   break;
            case 1: showBox      = !showBox;      break;
            case 2: showSkeleton = !showSkeleton; break;
            case 3: showLines    = !showLines;    break;
            case 4: showNames    = !showNames;    break;
            case 5: showHealth   = !showHealth;   break;
            case 6: showDistance = !showDistance; break;
            case 7:
                if      (maxEspDistance < 200) maxEspDistance = 200;
                else if (maxEspDistance < 300) maxEspDistance = 300;
                else if (maxEspDistance < 500) maxEspDistance = 500;
                else                           maxEspDistance = 100;
                break;
        }
        postInvalidate();
    }

    private void handleDebugTap(float tx, float ty) {
        // Тап за пределами debug-панели — закрываем
        float DBG_W = Math.min(screenW - 20f, 500f);
        float gearRight = gearX + GEAR_RADIUS + 14f;
        float mx = (gearRight + DBG_W < screenW - 8f) ? gearRight
                : Math.max(8f, gearX - GEAR_RADIUS - 14f - DBG_W);

        if (tx < mx || tx > mx + DBG_W) {
            debugMenuOpen = false; enableTouch(false); postInvalidate();
        }
    }
}
